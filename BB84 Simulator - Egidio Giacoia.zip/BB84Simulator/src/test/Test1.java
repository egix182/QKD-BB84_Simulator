package test;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

import coding.Channel;
import coding.Engine;
import coding.Receiver;
import coding.Sender;

public class Test1 {

	public static void main(String[] args) {
		/*Sender s = new Sender();
		Receiver r = new Receiver();
		Channel c = new Channel(s,r);
		Engine.setDefaultSchema();
		s.creationRawKey(10);
		System.out.println(Engine.getItems(s.getRawKey()));
		s.creationCasualBase();
		System.out.println(Engine.getItemsBase(s.getArrayBasiSender()));
		s.sendFotoni();
		System.out.println(Engine.getItemsFotone(s.getArrayFotoni()));
		System.out.println(Engine.getItemsBase(r.getArrayBasiReceiver()));
		System.out.println(Engine.getItems(r.getRawKey()));*/
		/*******************/
		/*TreeMap<Integer, Integer> map = new TreeMap<Integer, Integer>();
		map.put(0, 1);
		map.put(1, 1);
		map.put(2, 1);
		map.put(3, 0);
		map.put(4, 1);
		map.put(5, 1);
		map.put(6, 0);
		map.put(7, 0);
		map.put(8, 1);
		map.put(9, 1);
		TreeMap<Integer, Integer> array = Engine.extractBit(map, 0.3);
		Set<Integer> keys = array.keySet();
	    Iterator<Integer> itr = keys.iterator();
	    while (itr.hasNext()) { 
	       int k  = itr.next();
	       System.out.println("chiave: "+k+" Valore: "+ array.get(k));
	    } */
		/*******************/
		/*Sender s1 = new Sender();
		Receiver r1 = new Receiver();
		Channel c1 = new Channel(s1,r1);
		Engine.setDefaultSchema();
		s1.creationRawKey(10);
		System.out.println(Engine.getItems(s1.getRawKey()));
		s1.creationCasualBase();
		System.out.println(Engine.getItemsBase(s1.getArrayBasiSender()));
		int i=0;
		while( i <s1.getNQubits()){
			s1.sendFotone();
			i++;
		}
		c1.setQCActive(false);
		r1.sendBases();
		System.out.println("Basi Inviate da R: "+Engine.getItemsBase(r1.getArrayBasiReceiver()));
		System.out.println("Basi Ricevute da S: "+Engine.getItemsBase(s1.getArrayBasiReceiver()));
		s1.sendBases();
		System.out.println("Basi Inviate da S: "+Engine.getItemsBase(s1.getArrayBasiSender()));
		System.out.println("Basi Ricevute da R: "+Engine.getItemsBase(r1.getArrayBasiSender()));
		s1.checkBases();
		s1.creationSiftingKey();
		r1.checkBases();
		r1.creationSiftingKey();
		System.out.println(Engine.compareKey(s1.getKeySifting(), r1.getKeySifting()));
		System.out.println("Chiave S-Sifting: "+Engine.getItems(s1.getKeySifting()));
		System.out.println("Chiave R-Sifting: "+Engine.getItems(r1.getKeySifting()));
		s1.extractBitToCheck();
		s1.sendBits();
		s1.extractBitToCheck();
		s1.sendBits();
		r1.extractBitToCheck();
		r1.sendBits();
		s1.checkBitDistillation();
		r1.checkBitDistillation();
		s1.creationDistillationKey();
		r1.creationDistillationKey();
		System.out.println(Engine.compareKey(s1.getKeyDistillation(), r1.getKeyDistillation()));
		System.out.println("Chiave S-Distillation: "+Engine.getItems(s1.getKeyDistillation()));
		System.out.println("Chiave R-Distillation: "+Engine.getItems(r1.getKeyDistillation()));*/
		//System.out.println("Bit estratti S: "+Engine.getItems(s1.getArrayCheckBitSender()));
		//System.out.println("Bit ricevuti R: "+Engine.getItems(r1.getArrayCheckBitSender()));
		//r1.extractBitToCheck();
		//r1.sendBits();
		//System.out.println("Bit estratti R: "+Engine.getItems(r1.getArrayCheckBitReceiver()));
		//System.out.println("Bit ricevuti S: "+Engine.getItems(s1.getArrayCheckBitReceiver()));
		/*Set<Integer> keys = s1.getKeySifting().keySet();
	    Iterator<Integer> itr = keys.iterator();
	    while (itr.hasNext()) { 
	       int k  = itr.next();
	       System.out.println("chiave Sifting: "+k+" Valore: "+ s1.getKeySifting().get(k));
	    } 

		keys = s1.getArrayCheckBitSender().keySet();
	    itr = keys.iterator();
	    while (itr.hasNext()) { 
	       int k  = itr.next();
	       System.out.println("chiave: "+k+" Valore: "+ s1.getArrayCheckBitSender().get(k));
	    } */

	}

}
