package test;

import coding.Channel;
import coding.ChannelEavesdropper;
import coding.Eavesdropper;
import coding.ProtocolloBB84;
import coding.Receiver;
import coding.Sender;

public class Test3 {

	public static void main(String[] args) {
		/*ProtocolloBB84 b = new ProtocolloBB84(new Channel(new Sender(3000), new Receiver()));
		b.execute();
		b.info();*/
		//ProtocolloBB84 b = new ProtocolloBB84(new ChannelEavesdropper(new Sender(1024), new Receiver(), new Eavesdropper(1)));
		//ProtocolloBB84 b = new ProtocolloBB84(new Channel(new Sender(30), new Receiver()));
		//b.execute();
		//b.info();
		ProtocolloBB84 b = new ProtocolloBB84(new ChannelEavesdropper(new Sender(1024), new Receiver(), new Eavesdropper(10),50));
		System.out.println(b.infoProbabilitaStimata());
		b.execute();
	}

}
