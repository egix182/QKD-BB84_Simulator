package test;

import coding.Channel;
import coding.ChannelEavesdropper;
import coding.Engine;
import coding.Eavesdropper;
import coding.Receiver;
import coding.Sender;

public class Test2 {

	public static void main(String[] args) {
		/*Sender s1 = new Sender();
		Receiver r1 = new Receiver();
		Eavesdropper e = new Eavesdropper(0);
		ChannelEvesdropper c = new ChannelEvesdropper(s1,r1,e);
		Engine.setDefaultSchema();
		s1.creationRawKey(10);
		System.out.println(Engine.getItems(s1.getRawKey()));
		s1.creationCasualBase();
		System.out.println(Engine.getItemsBase(s1.getArrayBasiSender()));
		int i=0;
		while( i <s1.getNQubits()){
			s1.sendFotone();
			i++;
		}
		c.setQCActive(false);
		r1.sendBases();
		System.out.println("Basi Inviate da R: "+Engine.getItemsBase(r1.getArrayBasiReceiver()));
		System.out.println("Basi Ricevute da S: "+Engine.getItemsBase(s1.getArrayBasiReceiver()));
		s1.sendBases();
		System.out.println("Basi Inviate da S: "+Engine.getItemsBase(s1.getArrayBasiSender()));
		System.out.println("Basi Ricevute da R: "+Engine.getItemsBase(r1.getArrayBasiSender()));
		s1.checkBases();
		s1.creationSiftingKey();
		r1.checkBases();
		r1.creationSiftingKey();
		System.out.println(Engine.compareKey(s1.getKeySifting(), r1.getKeySifting()));
		System.out.println("Chiave S-Sifting: "+Engine.getItems(s1.getKeySifting()));
		System.out.println("Chiave R-Sifting: "+Engine.getItems(r1.getKeySifting()));
		s1.extractBitToCheck();
		s1.sendBits();
		s1.extractBitToCheck();
		s1.sendBits();
		r1.extractBitToCheck();
		r1.sendBits();
		s1.checkBitDistillation();
		r1.checkBitDistillation();
		s1.creationDistillationKey();
		r1.creationDistillationKey();
		System.out.println(Engine.compareKey(s1.getKeyDistillation(), r1.getKeyDistillation()));
		System.out.println("Chiave S-Distillation: "+Engine.getItems(s1.getKeyDistillation()));
		System.out.println("Chiave R-Distillation: "+Engine.getItems(r1.getKeyDistillation()));
		
		*/

	}

}
