package coding;

import java.util.TreeMap;

public class Eavesdropper {
	private int level;
	private TreeMap<Integer, Fotone> arrayFotoni;
	private TreeMap<Integer, Character> arrayBasiEve;
	private TreeMap<Integer, Character> arrayBasiSender;
	private TreeMap<Integer, Character> arrayBasiReceiver;
	private TreeMap<Integer, Integer> arrayCheckBitSender;
	private TreeMap<Integer, Integer> arrayCheckBitReceiver;
	private TreeMap<Integer, Character>  rawKey;
	private int indexBasi;
	private int indexBit;
	private int indexFotoni;
	private int indexIntercept;
	private double EVE_INTERCEPT;

	public Eavesdropper(int level){
		checkLevel(level);
		indexBasi = 0;
		indexBit = 0;
		indexFotoni = 0;
		indexIntercept = 0;
		arrayBasiEve= new TreeMap<Integer, Character>();
		rawKey = new TreeMap<Integer, Character>();
		arrayFotoni = new TreeMap<Integer, Fotone>();
	}
	
	private void checkLevel(int level){
		if(level < 1) { this.level = 1; this.EVE_INTERCEPT = 10; return;}
		if(level > 10){ this.level = 10; this.EVE_INTERCEPT = 100; return;}
		this.level = level;
		this.EVE_INTERCEPT = level *10;
	}
	
	public boolean tryGetPolarization(){
		int number = Engine.randomNumber(1, 10);
		if(level >= number) return true;
		else return false;
	}
	
	public Fotone notifyFotone(Fotone f){
		arrayBasiEve.put(indexBasi, Engine.randomBase());
		int bit = Engine.detection(f, arrayBasiEve.get(indexBasi));
		char car = (""+bit).charAt(0);
		rawKey.put(indexBit, car);
		Fotone f2 = Engine.polarizzation(bit, arrayBasiEve.get(indexBasi));
		arrayFotoni.put(indexFotoni, f2);
		indexFotoni++;
		indexBit++;
		indexBasi++;
		indexIntercept++;
		return f2;
	}
	
	public void notifyNoIntercept(){
		arrayBasiEve.put(indexBasi, '?');
		rawKey.put(indexBit, '?');
		Fotone f = new Fotone('?', (int) '?');
		arrayFotoni.put(indexFotoni, f);
		indexFotoni++;
		indexBit++;
		indexBasi++;
	}
	
	public void notifyBasesReceiver(TreeMap<Integer, Character> arrayBasi){
		this.arrayBasiReceiver = arrayBasi;
	}
	
	public void notifyBasesSender(TreeMap<Integer, Character> arrayBasi){
		this.arrayBasiSender = arrayBasi;
	}
	
	public void notifyBitsSender(TreeMap<Integer, Integer> arrayBits){
		this.arrayCheckBitSender = arrayBits;
	}
	
	public void notifyBitsReceiver(TreeMap<Integer, Integer> arrayBits){
		this.arrayCheckBitReceiver = arrayBits;
	}

	public TreeMap<Integer, Character> getArrayBasiEve() {
		return arrayBasiEve;
	}

	public void setArrayBasiEve(TreeMap<Integer, Character> arrayBasiEve) {
		this.arrayBasiEve = arrayBasiEve;
	}

	public TreeMap<Integer, Character> getArrayBasiSender() {
		return arrayBasiSender;
	}

	public void setArrayBasiSender(TreeMap<Integer, Character> arrayBasiSender) {
		this.arrayBasiSender = arrayBasiSender;
	}

	public TreeMap<Integer, Character> getArrayBasiReceiver() {
		return arrayBasiReceiver;
	}

	public void setArrayBasiReceiver(TreeMap<Integer, Character> arrayBasiReceiver) {
		this.arrayBasiReceiver = arrayBasiReceiver;
	}

	public TreeMap<Integer, Integer> getArrayCheckBitSender() {
		return arrayCheckBitSender;
	}

	public void setArrayCheckBitSender(TreeMap<Integer, Integer> arrayCheckBitSender) {
		this.arrayCheckBitSender = arrayCheckBitSender;
	}

	public TreeMap<Integer, Integer> getArrayCheckBitReceiver() {
		return arrayCheckBitReceiver;
	}

	public void setArrayCheckBitReceiver(TreeMap<Integer, Integer> arrayCheckBitReceiver) {
		this.arrayCheckBitReceiver = arrayCheckBitReceiver;
	}

	public TreeMap<Integer, Character> getRawKey() {
		return rawKey;
	}

	public void setRawKey(TreeMap<Integer, Character> rawKey) {
		this.rawKey = rawKey;
	}

	public TreeMap<Integer, Fotone> getArrayFotoni() {
		return arrayFotoni;
	}

	public void setArrayFotoni(TreeMap<Integer, Fotone> arrayFotoni) {
		this.arrayFotoni = arrayFotoni;
	}

	public int getIndexIntercept() {
		return indexIntercept;
	}

	public void setIndexIntercept(int indexIntercept) {
		this.indexIntercept = indexIntercept;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}
	
	public double getEVE_INTERCEPT() {
		return EVE_INTERCEPT;
	}

	public void setEVE_INTERCEPT(double EVE_INTERCEPT) {
		this.EVE_INTERCEPT = EVE_INTERCEPT;
	}
	
	
}
