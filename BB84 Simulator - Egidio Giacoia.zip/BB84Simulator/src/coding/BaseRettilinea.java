package coding;

public class BaseRettilinea extends Base{

	public BaseRettilinea() {
		super(new Fotone('|', 0), new Fotone('_', 90), 'R');
	}
	
}
