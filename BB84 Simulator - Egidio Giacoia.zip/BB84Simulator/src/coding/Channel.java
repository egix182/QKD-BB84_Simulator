package coding;

import java.util.TreeMap;

public class Channel {
	private double BIT_COMPARE;
	private final static double QBER = 11;
	private Sender sender;
	private Receiver receiver;
	private boolean QCActive = true;
	
	private double QberReal = 0;
	
	public Channel(Sender sender, Receiver receiver, double bitCompare){
		this.sender = sender;
		this.receiver = receiver;
		this.sender.setChannel(this);
		this.receiver.setChannel(this);
		this.BIT_COMPARE = bitCompare;
	}
	
	public void sendFotoneToReceiver(Fotone f){
		if(QCActive)
			receiver.notifyFotone(f);
		else{
			System.out.println("Canale Quantico non attivo");
		}
	}
	
	public void sendBasesToSender(TreeMap<Integer, Character> arrayBasi){
		if(QCActive == false)
			sender.notifyBases(arrayBasi);
		else{
			System.out.println("Canale Classico non attivo");
		}
	}
	
	public void sendBasesToReceiver(TreeMap<Integer, Character> arrayBasi){
		if(QCActive == false)
			receiver.notifyBases(arrayBasi);
		else{
			System.out.println("Canale Classico non attivo");
		}
	}

	public void sendBitsToReceiver(TreeMap<Integer, Integer> arrayBit){
		if(QCActive == false)
			receiver.notifyBits(arrayBit);
		else{
			System.out.println("Canale Classico non attivo");
		}
	}
	
	public void sendBitsToSender(TreeMap<Integer, Integer> arrayBit){
		if(QCActive == false)
			sender.notifyBits(arrayBit);
		else{
			System.out.println("Canale Classico non attivo");
		}
	}
	
	public boolean isQCActive() {
		return QCActive;
	}

	public void setQCActive(boolean qCActive) {
		QCActive = qCActive;
	}

	public double getBIT_COMPARE() {
		return BIT_COMPARE;
	}

	public void setBIT_COMPARE(double bIT_COMPARE) {
		BIT_COMPARE = bIT_COMPARE;
	}

	public static double getQber() {
		return QBER;
	}

	public Sender getSender() {
		return sender;
	}

	public void setSender(Sender sender) {
		this.sender = sender;
	}

	public Receiver getReceiver() {
		return receiver;
	}

	public void setReceiver(Receiver receiver) {
		this.receiver = receiver;
	}

	public double getQberReal() {
		return QberReal;
	}

	public void setQberReal(double qberReal) {
		QberReal = qberReal;
	}

	
}
