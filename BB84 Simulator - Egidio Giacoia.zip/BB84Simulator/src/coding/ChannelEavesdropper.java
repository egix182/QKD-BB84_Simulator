package coding;

import java.util.TreeMap;

public class ChannelEavesdropper extends Channel{

	Eavesdropper eve;
	public ChannelEavesdropper(Sender sender, Receiver receiver, Eavesdropper eve, double bitCompare) {
		super(sender, receiver, bitCompare);
		this.eve = eve;
	}
	
	@Override
	public void sendFotoneToReceiver(Fotone f) {
		if(eve.tryGetPolarization()){
			Fotone f2 = eve.notifyFotone(f);
			super.sendFotoneToReceiver(f2);
			
		}else {
			eve.notifyNoIntercept();
			super.sendFotoneToReceiver(f);
		}
	}
	
	@Override
	public void sendBasesToSender(TreeMap<Integer, Character> arrayBasi) {
		eve.notifyBasesReceiver(arrayBasi);
		super.sendBasesToSender(arrayBasi);
	}
	
	@Override
	public void sendBasesToReceiver(TreeMap<Integer, Character> arrayBasi) {
		eve.notifyBasesSender(arrayBasi);
		super.sendBasesToReceiver(arrayBasi);
	}
	
	@Override
	public void sendBitsToReceiver(TreeMap<Integer, Integer> arrayBit) {
		eve.notifyBitsSender(arrayBit);
		super.sendBitsToReceiver(arrayBit);
	}
	@Override
	public void sendBitsToSender(TreeMap<Integer, Integer> arrayBit) {
		eve.notifyBitsReceiver(arrayBit);
		super.sendBitsToSender(arrayBit);
	}

	public Eavesdropper getEve() {
		return eve;
	}

	public void setEve(Eavesdropper eve) {
		this.eve = eve;
	}
	
	
}
