package coding;

public class Base {
	private Fotone f0;
	private Fotone f1;
	private char code;
	
	
	public Base(Fotone f0, Fotone f1, char code){
		if(checkFilterPolarization(f0, f1)){
			this.f0 = f0;
			this.f1 = f1;
			this.code = code;
			f0.setQubit(0);
			f1.setQubit(1);
		}else{
			System.out.println("Errore costruzione base: non ortogonali!");
		}
	}
	
	public boolean checkBase(char simbolo){
		if(simbolo == getCode()) return true;
		return false;
	}
	
	public boolean checkFotoneBase(char simbolo){
		if(drawFotone0() == simbolo) return true;
		if(drawFotone1() == simbolo) return true;
		return false;
	}
	
	public Fotone getFotone(char simbolo){
		if(drawFotone0() == simbolo) return this.f0;
		if(drawFotone1() == simbolo) return this.f1;
		return null;
	}
	
	public Fotone getFotone0(){
		return this.f0;
	}
	
	public Fotone getFotone1(){
		return this.f1;
	}
	
	public int getFotoneQuBit0(){
		return this.f0.getQubit();
	}
	
	public int getFotoneBit1(){
		return this.f1.getQubit();
	}
	
	
	public char drawFotone0(){
		return this.f0.getSimbolo();
	}

	public char drawFotone1(){
		return this.f1.getSimbolo();
	}
	
	public char getCode(){
		return code;
	}
	
	private boolean checkFilterPolarization(Fotone f0, Fotone f1){
		if(Math.abs(f0.getAngolo() - f1.getAngolo()) != 90)return false;
		return true;
	}
}
