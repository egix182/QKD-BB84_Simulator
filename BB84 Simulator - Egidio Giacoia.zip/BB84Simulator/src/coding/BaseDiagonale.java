package coding;

public class BaseDiagonale extends Base {
	
	public BaseDiagonale() {
		super(new Fotone('/', 45), new Fotone('\\', 135), 'D');
	}
}
