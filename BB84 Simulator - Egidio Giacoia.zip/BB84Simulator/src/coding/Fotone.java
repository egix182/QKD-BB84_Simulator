package coding;

public class Fotone {
	private char simbolo;
	private int angolo;
	private int qubit;
	
	public Fotone(char simbolo, int angolo){
		if(checkAngolo(angolo)){
			this.simbolo = simbolo;
			this.angolo = angolo;
		}
	}
	
	private boolean checkAngolo(int angolo){
		if(angolo < 0 || angolo > 180) return false;
		return true;
	}
	
	public char getSimbolo() {
		return simbolo;
	}

	public void setSimbolo(char simbolo) {
		this.simbolo = simbolo;
	}

	public int getAngolo() {
		return angolo;
	}

	public void setAngolo(int angolo) {
		this.angolo = angolo;
	}

	public int getQubit() {
		return qubit;
	}

	public void setQubit(int qubit) {
		this.qubit = qubit;
	}
	
	
}
