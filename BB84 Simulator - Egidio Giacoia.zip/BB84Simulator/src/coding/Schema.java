package coding;

public class Schema {
	private Base b1;
	private Base b2;
	
	
	public Schema(Base b1, Base b2){
		if(checkSchemaOrtogonale(b1,b2)){
			this.b1 = b1; 
			this.b2 = b2;
		}else{
			System.out.println("Errore costruzione Schema: non coniugate");
		}
	}
	
	public Fotone polarizzation(int bit, char base){
		if(base == getBase1().getCode()){
			if(bit == 0)
				return new Fotone(b1.getFotone0().getSimbolo(),
						b1.getFotone0().getAngolo());
			if(bit == 1)
				return new Fotone(b1.getFotone1().getSimbolo(),
						b1.getFotone1().getAngolo());
		}
		if(base == getBase2().getCode()){
			if(bit == 0)
				return new Fotone(b2.getFotone0().getSimbolo(),
						b2.getFotone0().getAngolo());
			if(bit == 1)
				return new Fotone(b2.getFotone1().getSimbolo(),
						b2.getFotone1().getAngolo());
		}
		
		return null;
	}
	
	public Base getBase1(){
		return b1;
	}
	
	public Base getBase2(){
		return b2;
	}
	private boolean checkSchemaOrtogonale(Base b1, Base b2){
		if(Math.abs(b1.getFotone0().getAngolo() - b2.getFotone0().getAngolo()) != 45){
			return false;
		}else if(Math.abs(b1.getFotone1().getAngolo() - b2.getFotone1().getAngolo()) != 45){
			return false;
		}
		return true;
	}
	
}
