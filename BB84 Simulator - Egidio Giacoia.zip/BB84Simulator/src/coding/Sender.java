package coding;

import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

public class Sender {
	
	private int NQubits; 
	private TreeMap<Integer, Fotone>  arrayFotoni;
	private TreeMap<Integer, Integer>  rawKey;
	private TreeMap<Integer, Character> arrayBasiSender;
	private TreeMap<Integer, Character> arrayBasiReceiver;
	private TreeMap<Integer, Boolean> arrayCheck;
	private TreeMap<Integer, Integer>  keySifting ;
	private TreeMap<Integer, Integer> arrayCheckBitSender;
	private TreeMap<Integer, Integer> arrayCheckBitReceiver;
	private TreeMap<Integer, Boolean> arrayCheckBit;
	private TreeMap<Integer, Integer>  keyDistillation ;
	private Channel channel;
	
	private int indexFotoni;
	private int indexBasi;
	private int indexBit;
	

	public Sender(int NQubits){
		this.NQubits = NQubits;
		arrayFotoni = new TreeMap<Integer, Fotone>();
		indexFotoni = 0;
		indexBasi = 0;
		indexBit = 0;
	}
	
	public void creationRawKey(){
		rawKey = new TreeMap<Integer, Integer>();
		for(int i=0; i<NQubits; i++){
			rawKey.put(i, Engine.randomBit());
		}	
	}
	
	public void creationCasualBase(){
		arrayBasiSender = new TreeMap<Integer, Character>();
		for(int i=0; i<NQubits; i++){
			arrayBasiSender.put(i, Engine.randomBase());
		}	
	}
	
	public void sendFotoni(){
		arrayFotoni = Engine.polarizzation(rawKey, arrayBasiSender);
		Set<Integer> keys = arrayFotoni.keySet();
	    Iterator<Integer> itr = keys.iterator();
	    while (itr.hasNext()) { 
	       int i  = itr.next();
	       channel.sendFotoneToReceiver(arrayFotoni.get(i));
	    } 
	}
	
	public void sendFotone(){
		Fotone f = Engine.polarizzation(rawKey.get(indexBit), arrayBasiSender.get(indexBasi));
		arrayFotoni.put(indexFotoni, f);
		channel.sendFotoneToReceiver(f);
		indexBit++;
		indexFotoni++;
		indexBasi++;
	}
	
	public void sendBases(){
		channel.sendBasesToReceiver(arrayBasiSender);
	}
	
	public void checkBases(){
		arrayCheck = Engine.checkEquality(arrayBasiSender, arrayBasiReceiver);
	}
	
	public void creationSiftingKey(){
		keySifting = Engine.filteredKey(rawKey, arrayCheck);
	}
	
	public void extractBitToCheck(){
		arrayCheckBitSender = Engine.extractBit(keySifting, channel.getBIT_COMPARE());
	}
	
	public void sendBits(){
		channel.sendBitsToReceiver(arrayCheckBitSender);
	}
	
	public void checkBitDistillation(){
		arrayCheckBit = Engine.checkEqualityBit(arrayCheckBitSender, arrayCheckBitReceiver);
	}
		
	public void creationDistillationKey() throws Exception{
		int counter = Engine.checkNumberBitFalse(arrayCheckBit);
		double percentuale = (100*counter)/arrayCheckBit.size();
		this.channel.setQberReal(percentuale);
		if(counter == 0){
			keyDistillation = Engine.filteredKeyDistillation(keySifting, arrayCheckBit);
		}else{
			throw new Exception("Presenza Rilevata");
		}

	}
	
	public void notifyBases(TreeMap<Integer, Character> arrayBasi){
		this.arrayBasiReceiver = arrayBasi;
	}
	
	public void notifyBits(TreeMap<Integer, Integer> arrayBits){
		this.arrayCheckBitReceiver = arrayBits;
	}
	
	public TreeMap<Integer, Fotone> getArrayFotoni() {
		return arrayFotoni;
	}

	public void setArrayFotoni(TreeMap<Integer, Fotone> arrayFotoni) {
		this.arrayFotoni = arrayFotoni;
	}

	public TreeMap<Integer, Integer> getRawKey() {
		return rawKey;
	}

	public void setRawKey(TreeMap<Integer, Integer> rawKey) {
		this.rawKey = rawKey;
	}

	public TreeMap<Integer, Character> getArrayBasiSender() {
		return arrayBasiSender;
	}

	public void setArrayBasiSender(TreeMap<Integer, Character> arrayBasiSender) {
		this.arrayBasiSender = arrayBasiSender;
	}

	public TreeMap<Integer, Character> getArrayBasiReceiver() {
		return arrayBasiReceiver;
	}

	public void setArrayBasiReceiver(TreeMap<Integer, Character> arrayBasiReceiver) {
		this.arrayBasiReceiver = arrayBasiReceiver;
	}

	public TreeMap<Integer, Boolean> getArrayCheck() {
		return arrayCheck;
	}

	public void setArrayCheck(TreeMap<Integer, Boolean> arrayCheck) {
		this.arrayCheck = arrayCheck;
	}

	public TreeMap<Integer, Integer> getKeySifting() {
		return keySifting;
	}

	public void setKeySifting(TreeMap<Integer, Integer> keySifting) {
		this.keySifting = keySifting;
	}
	
	
	
	public TreeMap<Integer, Integer> getArrayCheckBitSender() {
		return arrayCheckBitSender;
	}

	public void setArrayCheckBitSender(TreeMap<Integer, Integer> arrayCheckBitSender) {
		this.arrayCheckBitSender = arrayCheckBitSender;
	}

	public TreeMap<Integer, Integer> getKeyDistillation() {
		return keyDistillation;
	}

	public void setKeyDistillation(TreeMap<Integer, Integer> keyDistillation) {
		this.keyDistillation = keyDistillation;
	}
	
	

	public TreeMap<Integer, Integer> getArrayCheckBitReceiver() {
		return arrayCheckBitReceiver;
	}

	public void setArrayCheckBitReceiver(TreeMap<Integer, Integer> arrayCheckBitReceiver) {
		this.arrayCheckBitReceiver = arrayCheckBitReceiver;
	}

	public int getNQubits() {
		return NQubits;
	}

	public void setNQubits(int nQubits) {
		NQubits = nQubits;
	}

	public Channel getChannel() {
		return channel;
	}

	public void setChannel(Channel channel) {
		this.channel = channel;
	}

	public TreeMap<Integer, Boolean> getArrayCheckBit() {
		return arrayCheckBit;
	}

	public void setArrayCheckBit(TreeMap<Integer, Boolean> arrayCheckBit) {
		this.arrayCheckBit = arrayCheckBit;
	}
	
	
}
