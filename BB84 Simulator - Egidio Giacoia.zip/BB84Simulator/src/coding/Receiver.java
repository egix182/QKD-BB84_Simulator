package coding;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.TreeMap;

public class Receiver {

	private TreeMap<Integer, Fotone>  arrayFotoniSender;
	private TreeMap<Integer, Integer>  rawKey;
	private TreeMap<Integer, Character> arrayBasiSender;
	private TreeMap<Integer, Character> arrayBasiReceiver;
	private TreeMap<Integer, Boolean> arrayCheck;
	private TreeMap<Integer, Integer>  keySifting ;
	private TreeMap<Integer, Integer> arrayCheckBitSender;
	private TreeMap<Integer, Integer> arrayCheckBitReceiver;
	private TreeMap<Integer, Boolean> arrayCheckBit;
	private TreeMap<Integer, Integer>  keyDistillation ;
	private Channel channel;
	private int indexBasi;
	private int indexBit;
		
	public Receiver(){
		arrayBasiReceiver = new TreeMap<Integer, Character>();
		rawKey = new TreeMap<Integer, Integer>();
		indexBasi= 0;
		indexBit = 0;
	}
	
	public void sendBases(){
		channel.sendBasesToSender(arrayBasiReceiver);
	}
	
	public void checkBases(){
		arrayCheck = Engine.checkEquality(arrayBasiReceiver, arrayBasiSender);
	}
	
	public void creationSiftingKey(){
		keySifting = Engine.filteredKey(rawKey, arrayCheck);
	}
		
	public void extractBitToCheck(){
		arrayCheckBitReceiver = Engine.extractBit(keySifting, channel.getBIT_COMPARE());
	}
	
	public void sendBits(){
		channel.sendBitsToSender(arrayCheckBitReceiver);
	}
	
	public void checkBitDistillation(){
		arrayCheckBit = Engine.checkEqualityBit(arrayCheckBitReceiver, arrayCheckBitSender);
	}
	
	public void creationDistillationKey() throws Exception{
		int counter = Engine.checkNumberBitFalse(arrayCheckBit);
		double percentuale = (100*counter)/arrayCheckBit.size();
		if(counter == 0){
			keyDistillation = Engine.filteredKeyDistillation(keySifting, arrayCheckBit);
		}else{
				throw new Exception("Presenza Rilevata");
		}
	}
	
	public void notifyFotone(Fotone f){
		arrayBasiReceiver.put(indexBasi, Engine.randomBase());
		int bit = Engine.detection(f, arrayBasiReceiver.get(indexBasi));
		rawKey.put(indexBit, bit);
		indexBit++;
		indexBasi++;		
	}
	
	public void notifyBases(TreeMap<Integer, Character> arrayBasi){
		this.arrayBasiSender = arrayBasi;
	}
	
	public void notifyBits(TreeMap<Integer, Integer> arrayBits){
		this.arrayCheckBitSender = arrayBits;
	}
	

	public TreeMap<Integer, Fotone> getArrayFotoniSender() {
		return arrayFotoniSender;
	}
	


	public void setArrayFotoniSender(TreeMap<Integer, Fotone> arrayFotoniSender) {
		this.arrayFotoniSender = arrayFotoniSender;
	}


	public TreeMap<Integer, Integer> getRawKey() {
		return rawKey;
	}


	public void setRawKey(TreeMap<Integer, Integer> rawKey) {
		this.rawKey = rawKey;
	}


	public TreeMap<Integer, Character> getArrayBasiSender() {
		return arrayBasiSender;
	}


	public void setArrayBasiSender(TreeMap<Integer, Character> arrayBasiSender) {
		this.arrayBasiSender = arrayBasiSender;
	}


	public TreeMap<Integer, Character> getArrayBasiReceiver() {
		return arrayBasiReceiver;
	}


	public void setArrayBasiReceiver(TreeMap<Integer, Character> arrayBasiReceiver) {
		this.arrayBasiReceiver = arrayBasiReceiver;
	}


	public TreeMap<Integer, Boolean> getArrayCheck() {
		return arrayCheck;
	}


	public void setArrayCheck(TreeMap<Integer, Boolean> arrayCheck) {
		this.arrayCheck = arrayCheck;
	}


	public TreeMap<Integer, Integer> getKeySifting() {
		return keySifting;
	}


	public void setKeySifting(TreeMap<Integer, Integer> keySifting) {
		this.keySifting = keySifting;
	}

	

	public TreeMap<Integer, Integer> getArrayCheckBitSender() {
		return arrayCheckBitSender;
	}

	public void setArrayCheckBitSender(TreeMap<Integer, Integer> arrayCheckBitSender) {
		this.arrayCheckBitSender = arrayCheckBitSender;
	}
	
	

	public TreeMap<Integer, Integer> getArrayCheckBitReceiver() {
		return arrayCheckBitReceiver;
	}

	public void setArrayCheckBitReceiver(TreeMap<Integer, Integer> arrayCheckBitReceiver) {
		this.arrayCheckBitReceiver = arrayCheckBitReceiver;
	}

	public TreeMap<Integer, Integer> getKeyDistillation() {
		return keyDistillation;
	}

	public void setKeyDistillation(TreeMap<Integer, Integer> keyDistillation) {
		this.keyDistillation = keyDistillation;
	}

	public Channel getChannel() {
		return channel;
	}


	public void setChannel(Channel channel) {
		this.channel = channel;
	}

	public TreeMap<Integer, Boolean> getArrayCheckBit() {
		return arrayCheckBit;
	}

	public void setArrayCheckBit(TreeMap<Integer, Boolean> arrayCheckBit) {
		this.arrayCheckBit = arrayCheckBit;
	}	
	
	
}
