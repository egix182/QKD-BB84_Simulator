package coding;

import coding.Channel;
import coding.Engine;
import coding.Receiver;
import coding.Sender;

public class ProtocolloBB84 {

	private Channel c;
	private Sender s;
	private Receiver r;
	private Eavesdropper e;
	private boolean eveActive = false;
	
	public ProtocolloBB84(Channel c){
		this.c = c;
		this.s = c.getSender();
		this.r = c.getReceiver();
		if(c instanceof ChannelEavesdropper){
			eveActive = true;
			this.e = ((ChannelEavesdropper) c).getEve();
		}
	}
	
	public  void codifyAndSend(){
		System.out.println("FASE 1 - Codifica e Invio Fotoni");
		Engine.setDefaultSchema();
		s.creationRawKey();
		System.out.println("S RawKey:	"+Engine.getItems(s.getRawKey()));
		s.creationCasualBase();
		System.out.println("S Basi:		"+Engine.getItemsBase(s.getArrayBasiSender()));
		int i=0;
		while( i < s.getNQubits()){
			s.sendFotone();
			i++;
		}
		System.out.println("S Fotoni:	"+Engine.getItemsFotone(s.getArrayFotoni()));
		if(eveActive){
		System.out.println("E Base:		"+Engine.getItemsBase(e.getArrayBasiEve()));
		System.out.println("E rawKey:	"+Engine.getItemsBase(e.getRawKey()));
		System.out.println("E Fotoni:	"+Engine.getItemsFotone(e.getArrayFotoni()));
		}
		
	}
	
	public void read(){
		System.out.println("FASE 2 - Lettura Fotoni");
		System.out.println("R Basi:		"+Engine.getItemsBase(r.getArrayBasiReceiver()));
		System.out.println("R rawKey:	"+Engine.getItems(r.getRawKey()));
		c.setQCActive(false);
	}
	

	public void sifting(){
		System.out.println("FASE 3 - SiftingKey");
		r.sendBases();
		s.sendBases();
		s.checkBases();
		s.creationSiftingKey();
		r.checkBases();
		r.creationSiftingKey();
		System.out.println("S-Sifting: 	"+Engine.getItems(s.getKeySifting()));
		System.out.println("R-Sifting: 	"+Engine.getItems(r.getKeySifting()));
	}
	
	public void distillation(){
		System.out.println("FASE 4 - DistillationKey");
		s.extractBitToCheck();
		s.sendBits();
		System.out.println("S bit: 		"+Engine.getItems(s.getArrayCheckBitSender()));
		r.extractBitToCheck();
		r.sendBits();
		System.out.println("R bit: 		"+Engine.getItems(r.getArrayCheckBitReceiver()));
		s.checkBitDistillation();
		r.checkBitDistillation();
		try {
			s.creationDistillationKey();
			r.creationDistillationKey();
			System.out.println("S-Key: 		"+Engine.getItems(s.getKeyDistillation()));
			System.out.println("R-Key: 		"+Engine.getItems(r.getKeyDistillation()));
		} catch (Exception e) {
			System.out.println(e.getMessage());
			info();
			//System.exit(1);
		}
		
	}
	
	public void execute(){
		this.codifyAndSend();
		this.read();
		this.sifting();
		this.distillation();
		System.out.println("Chiavi uguali:"+Engine.compareKey(s.getKeyDistillation(), r.getKeyDistillation()));
	}
	
	public String info(){
		String infoString = "";
		infoString+="/************Informazioni Generali************/\n";
		infoString+="RawKey Size: "+s.getRawKey().size()+"\n";
		infoString+= "SifitingKey Size: "+s.getKeySifting().size()+"\n";		
	
		
		System.out.println("RawKey Size:			"+s.getRawKey().size());
		System.out.println("Key Sifting Size:		"+s.getKeySifting().size());
		System.out.println("Bit Check Size: 		"+s.getArrayCheckBitSender().size());
		try{
			System.out.println("Key Distillation Size:	"+s.getKeyDistillation().size());
			infoString+= "DistillationKey Size:	"+s.getKeyDistillation().size()+"\n";
		}catch (Exception exp) {
		}finally{
			//infoString+= "QBER real: 			"+c.getQberReal()+"\n";
			//System.out.println("QBER real: 			"+c.getQberReal());
			infoString+= "Percentuale di Bit da Controllare: "+c.getBIT_COMPARE()+"\n";
			if(eveActive ==true){
				infoString+= "Eve livello: "+e.getLevel()+"\n";
				infoString+= "Eve interventi: "+e.getIndexIntercept()+"\n";
				System.out.println("Eve interception:		"+e.getIndexIntercept());
				System.out.println("Eve level:			"+e.getLevel());
				
			}
			System.out.println("Probabilit� Errore Bob: "+this.probabilitaEffettivaErroreReceiver());
			System.out.println("Probabilit� chiave diversa: "+this.probabilit�EffettivaDiscrepanzaChiavi());
			System.out.println("Probabilit� numero bit diversi:	"+this.numeroBitEffettiviDifferrentiChiave());
			System.out.println("Probabilit� Eve non rilevato:	"+this.probabilit�EffettivaEveNonRilevato());
			
			infoString+="/************Probabilit� Effettive************/\n";
			if(eveActive ==true){
				double x = ((e.getIndexIntercept() * 100.00)/s.getNQubits()/100.00);
				infoString+= "Probabilit� Eve intromissione:	"+x+"\n";
			}
			
			infoString+="Probabilit� Errore Bob (singola ricezione): "+this.probabilitaEffettivaErroreReceiver()+"\n";
			infoString+= "Probabilit� SiftingKey diversa: "+this.probabilit�EffettivaDiscrepanzaChiavi()+"\n";
			int numeroBitComparati = (int) Math.round((s.getKeySifting().size())* c.getBIT_COMPARE() /100);
			infoString+= "Numero di bit controllati: "+numeroBitComparati+"\n";
			infoString+= "Numero di bit controllati diversi: "+Engine.checkNumberBitFalse(this.s.getArrayCheckBit())+"\n";
			infoString+= "Probabilit� Eve non rilevato: "+this.probabilit�EffettivaEveNonRilevato()+"\n";
			infoString+= this.infoProbabilitaStimata();
		}
		
		return infoString;
	}

	public Channel getC() {
		return c;
	}

	public Sender getS() {
		return s;
	}

	public Receiver getR() {
		return r;
	}

	public Eavesdropper getE() {
		return e;
	}

	public boolean isEveActive() {
		return eveActive;
	}
	
	public double probabilitaStimataErroreReceiver(){
		double eve_perc;
		if(isEveActive())eve_perc = e.getEVE_INTERCEPT()/100.00;
		else eve_perc = 0;
		return (1.0/4.0) + (eve_perc/8.0);
	}
	
	public double probabilit�StimataDiscrepanzaChiavi(){
		double eve_perc;
		if(isEveActive())eve_perc = (double) e.getEVE_INTERCEPT()/100.00;
		else eve_perc = 0;
		return eve_perc/4.0;
	}
	
	public int numeroBitStimatiDifferrentiChiave(){
		double eve_perc;
		if(isEveActive())eve_perc = (int)e.getEVE_INTERCEPT()/100.00;
		else eve_perc = 0;
		
		int numeroBitComparati = (int) Math.round((s.getNQubits()/2.0)* c.getBIT_COMPARE()/100);
		return (int) Math.round((numeroBitComparati*((eve_perc)/4.0)));
	}
	
	public double probabilit�StimataEveNonRilevato(){
		double eve_perc;
		if(isEveActive())eve_perc = (int)e.getEVE_INTERCEPT()/100.00;
		else eve_perc = 0;
	
		int numeroBitComparati = (int) Math.round((s.getNQubits()/2.0)* c.getBIT_COMPARE() /100);
		double x = 1-(eve_perc/4.0);
		return Math.pow(x, numeroBitComparati);
	}
	
	public String infoProbabilitaStimata(){
		String infoString = "";
		infoString+="/************Probabilit� Stimata************/\n";
		if(isEveActive())infoString+= "Probabilit� Stimata Eve intromissione: "+this.e.getEVE_INTERCEPT()/100.00+"\n";
		infoString+="Probabilit� Stimata Errore Bob (singola ricezione): "+this.probabilitaStimataErroreReceiver()+"\n";
		infoString+= "Probabilit� Stimata SiftingKey diversa: "+this.probabilit�StimataDiscrepanzaChiavi()+"\n";
		int numeroBitComparati = (int) Math.round((s.getNQubits()/2.0)* c.getBIT_COMPARE() /100);
		infoString+= "Numero stimato bit da controllare: "+numeroBitComparati+"\n";
		infoString+= "Numero stimato bit di controllo diversi: "+this.numeroBitStimatiDifferrentiChiave()+"\n";
		infoString+= "Probabilit� Stimata Eve non rilevato:	"+this.probabilit�StimataEveNonRilevato()+"\n";
	
		return infoString;
	}
	
	public double probabilitaEffettivaErroreReceiver(){
		double eve_perc;
		if(isEveActive())eve_perc = ((e.getIndexIntercept() * 100.00)/s.getNQubits()/100.00);
		else eve_perc = 0;
		
		return (1.0/4.0) + (eve_perc/8.0);
	}
	
	public double probabilit�EffettivaDiscrepanzaChiavi(){
		double eve_perc;
		if(isEveActive())eve_perc = ((e.getIndexIntercept() * 100.00)/s.getNQubits()/100.00);
		else eve_perc = 0;
		return eve_perc/4.0;
	}
	
	public int numeroBitEffettiviDifferrentiChiave(){
		double eve_perc;
		if(isEveActive())eve_perc = ((e.getIndexIntercept() * 100.00)/s.getNQubits()/100.00);
		else eve_perc = 0;
		int numeroBitComparati = (int) Math.round((s.getKeySifting().size())* c.getBIT_COMPARE() /100);
	
		return (int) Math.round((numeroBitComparati*((eve_perc)/4.0)));
		
	
	}
	
	public double probabilit�EffettivaEveNonRilevato(){
		double eve_perc;
		if(isEveActive())eve_perc = ((e.getIndexIntercept() * 100.00)/s.getNQubits()/100.00);
		else eve_perc = 0;
	
		int numeroBitComparati = (int) Math.round((s.getKeySifting().size())* c.getBIT_COMPARE() /100);
		double x = 1-(eve_perc/4.0);
		return Math.pow(x, numeroBitComparati);		
	}
		
	public String infoProbabilitaEffettiva(){
		String infoString = "";
		infoString+="/************Probabilit� Effettive************/";
		try{
			infoString+="Probabilit� Errore Bob:	"+this.probabilitaEffettivaErroreReceiver()+"\n";
			infoString+= "Probabilit� chiave diversa:	"+this.probabilit�EffettivaDiscrepanzaChiavi()+"\n";
			infoString+= "Probabilit� numero bit diversi:	"+this.numeroBitEffettiviDifferrentiChiave()+"\n";
			infoString+= "Probabilit� Eve non rilevato:	"+this.probabilit�EffettivaEveNonRilevato()+"\n";
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		
	
		return infoString;
	}
}
