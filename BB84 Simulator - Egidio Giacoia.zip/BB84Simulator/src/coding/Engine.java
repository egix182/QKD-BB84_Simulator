package coding;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.io.File;
import java.util.ArrayList;
import java.util.TreeMap;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class Engine {
	
	public static Schema s;
	public static Random generator = new Random(System.currentTimeMillis());
	
	public static double randomGenerator() 
	{
		return generator.nextDouble();
	}
	
	public static void setSchema(Base b1, Base b2){
		s = new Schema(b1,b2);
	}
	
	public static void setDefaultSchema(){
		s = new Schema(new BaseRettilinea(), new BaseDiagonale());
	}
	
	public static int randomBit(){
		double b = randomGenerator();
		if(b<0.5) return 0;
		else return 1;
	}
	
	public static Character randomBase(){
		double b = randomGenerator();
		if(b<0.5) return s.getBase1().getCode();
		else return s.getBase2().getCode();
	}
	
	
	
	public static Fotone polarizzation(int bit, char base){
		if(base == s.getBase1().getCode()){
			if(bit == 0)
				return new Fotone(s.getBase1().getFotone0().getSimbolo(),
						s.getBase1().getFotone0().getAngolo());
			if(bit == 1)
				return new Fotone(s.getBase1().getFotone1().getSimbolo(),
						s.getBase1().getFotone1().getAngolo());
		}
		if(base == s.getBase2().getCode()){
			if(bit == 0)
				return new Fotone(s.getBase2().getFotone0().getSimbolo(),
						s.getBase2().getFotone0().getAngolo());
			if(bit == 1)
				return new Fotone(s.getBase2().getFotone1().getSimbolo(),
						s.getBase2().getFotone1().getAngolo());
		}
		
		return null;
	}
	
	public static TreeMap<Integer, Fotone> polarizzation(TreeMap<Integer, Integer> rawKey, 
			TreeMap<Integer, Character> arrayBase){
		if(rawKey.size() != arrayBase.size()) return null;
		TreeMap<Integer, Fotone> arrayToReturn = new TreeMap<Integer, Fotone>();
		Set<Integer> keys = rawKey.keySet();
		Iterator<Integer> itr = keys.iterator();
	    while (itr.hasNext()) { 
	       int i  = itr.next();
	       Fotone f = Engine.polarizzation(rawKey.get(i), arrayBase.get(i));
	       arrayToReturn.put(i, f);
	    } 
	    return arrayToReturn;
	}
	
	public static int detection(Fotone f, Character base){
		if(s.getBase1().getCode() == base){
			if(s.getBase1().checkFotoneBase(f.getSimbolo()))
				return s.getBase1().getFotone(f.getSimbolo()).getQubit();
			else return randomBit();
		}
		
		if(s.getBase2().getCode() == base){
			if(s.getBase2().checkFotoneBase(f.getSimbolo()))
				return s.getBase2().getFotone(f.getSimbolo()).getQubit();
			else return randomBit();
		}
		
		return -99;
	}
    
	public static TreeMap<Integer,Boolean> checkEquality(TreeMap<Integer,Character> array1,
			TreeMap<Integer,Character> array2){
		String items1 = Engine.getItemsBase(array1);
		String items2 = Engine.getItemsBase(array2);
		TreeMap<Integer,Boolean> arrayToReturn = new TreeMap<Integer,Boolean>();
		for (int i = 0; i < items1.length(); i++) {
			if(items1.charAt(i) == items2.charAt(i)){
				arrayToReturn.put(i, true);
			}else arrayToReturn.put(i, false);
		}
		return arrayToReturn;
	}
	
	public static TreeMap<Integer,Boolean> checkEqualityBit(TreeMap<Integer,Integer> array1,
			TreeMap<Integer,Integer> array2){
		String items1 = Engine.getItems(array1);
		String items2 = Engine.getItems(array2);
		TreeMap<Integer,Boolean> arrayToReturn = new TreeMap<Integer,Boolean>();
		for (int i = 0; i < items1.length(); i++) {
			if(items1.charAt(i) == items2.charAt(i)){
				arrayToReturn.put(i, true);
			}else arrayToReturn.put(i, false);
		}
		return arrayToReturn;
	}
	
	public static TreeMap<Integer, Integer> filteredKey(TreeMap<Integer, Integer> rawKey, TreeMap<Integer, Boolean> arrayCheck){
		TreeMap<Integer, Integer> arrayToReturn = (TreeMap<Integer, Integer>) rawKey.clone();
		Set<Integer> keys = arrayCheck.keySet();
	    Iterator<Integer> itr = keys.iterator();
	    while (itr.hasNext()) { 
	       int i  = itr.next();
	       if(!arrayCheck.get(i)) arrayToReturn.remove(i);
	    } 
	    return arrayToReturn;
	}
	
	public static TreeMap<Integer, Integer> filteredKeyDistillation(TreeMap<Integer, Integer> siftingKey, TreeMap<Integer, Boolean> arrayCheckBit ){
		TreeMap<Integer, Integer> arrayToReturn = new TreeMap<Integer, Integer>();
		Set<Integer> keys = siftingKey.keySet();
	    Iterator<Integer> itr = keys.iterator();
		int count = 0;
	    while(itr.hasNext()){
	    	int i = itr.next();
	    	if(count % 2 != 0) arrayToReturn.put(i, siftingKey.get(i));
	    	count++;
	    }
	
	    return arrayToReturn;
	}
	
	public static int checkNumberBitFalse(TreeMap<Integer, Boolean> arrayCheck){
		int counter = 0;
		Set<Integer> keys = arrayCheck.keySet();
	    Iterator<Integer> itr = keys.iterator();
	    while (itr.hasNext()) { 
	       int k  = itr.next();
	       if(!arrayCheck.get(k))
	    	   counter++;
	    } 
	    return counter;
	}
	
	public static boolean compareKey(TreeMap<Integer, Integer> array1, TreeMap<Integer, Integer> array2){
		String keySender = Engine.getItems(array1);
		String keyReceiver = Engine.getItems(array2);
		if (keySender.equals(keyReceiver)) return true;
		else return false;
	}
	
	public static int randomNumber(int min, int max){
		Random r = new Random();
		return r.nextInt(max - min + 1) + min;
	}
		
	public static TreeMap<Integer, Integer> extractBit(TreeMap<Integer, Integer> array, double pecentuale){
		TreeMap<Integer, Integer> arrayToReturn = new TreeMap<Integer, Integer>();
		int numberBit = (int) Math.round(array.size() * pecentuale /100);
		Set<Integer> keys = array.keySet();
		int jump = 0;
		Iterator<Integer> itr = keys.iterator();
		for(int i=1; i<=numberBit; i++){
			int k=0;
			while(jump % 2 != 0){
				k = itr.next();
				jump++;
			}
			k = itr.next();
			arrayToReturn.put(k,array.get(k));
			jump++;
		}
		
		return arrayToReturn;
	}
	
	public static String getItems(TreeMap<Integer, Integer> array){
		String s="";
		Set<Integer> keys = array.keySet();
	    Iterator<Integer> itr = keys.iterator();
	    while (itr.hasNext()) { 
	       int i  = itr.next();
	       s += ""+array.get(i)+"";
	    } 
	    return s;
	} 
		
	public static String getItemsBase(TreeMap<Integer, Character> array){
		String s="";
		Set<Integer> keys = array.keySet();
	    Iterator<Integer> itr = keys.iterator();
	    while (itr.hasNext()) { 
	       int i  = itr.next();
	       s += ""+array.get(i)+"";
	    } 
	    return s;
	} 
	
	public static String getItemsFotone(TreeMap<Integer, Fotone> array){
		String s="";
		Set<Integer> keys = array.keySet();
	    Iterator<Integer> itr = keys.iterator();
	    while (itr.hasNext()) { 
	       int i  = itr.next();
	       s += ""+array.get(i).getSimbolo()+"";
	    } 
	    return s;
	} 
	

	
}
