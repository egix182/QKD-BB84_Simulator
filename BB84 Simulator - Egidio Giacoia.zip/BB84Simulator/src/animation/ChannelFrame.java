package animation;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Timer;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;

import coding.Engine;

public class ChannelFrame extends JPanel implements ActionListener{
	protected MainFrame frame; 
	protected JLabel labelDisplay1;
	protected JLabel labelDisplay2;
	protected JPanel panelDisp1;
	protected JPanel panelDisp2;
	protected JPanel panelContainer;
	protected JLabel picLabelE;
	protected JLabel labelBaseEve;
	protected JPanel panelEve;
	protected JPanel panelUp;
	protected JButton play;
	protected AnimationFotoni animationFotoni;
	protected AnimationClassicChannel animationClassicChannel;
	protected AnimationBit animationBit;
	protected JLabel picLabelC;
	protected JPanel paneletichette;
	protected JPanel paneletichetteEve;
	protected JPanel panelDispEve;
	protected BufferedImage pictureEve;
	protected JPanel panelInfoEve;
	protected JButton showInfo;
	
	
	
	public ChannelFrame(MainFrame frame){
		this.frame = frame;
        this.setLayout(new GridLayout(3,1));
        
        panelUp = new JPanel();
        panelUp.setLayout(new BorderLayout());
        panelDisp1 = new JPanel();
        panelDisp1.setLayout(new FlowLayout());
        panelDisp1.setBorder(BorderFactory.createTitledBorder("Fase"));
        labelDisplay1 = new JLabel(frame.fase0);
        labelDisplay1.setFont(new Font("Serif", Font.PLAIN, 30));
        panelDisp1.add(labelDisplay1);


        panelUp.add(panelDisp1, BorderLayout.NORTH);
        
        panelDispEve = new JPanel();
        panelUp.add(panelDispEve, BorderLayout.CENTER);
        
       
        this.add(panelUp);
       
        
        BufferedImage pictureChannel = null;
        
    	try {
    		
    		URL url = getClass().getResource("/images/Channel2.png");
			pictureChannel = ImageIO.read(url);
    		 
			//pictureChannel = ImageIO.read(new File("Channel2.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	picLabelC = new JLabel(new ImageIcon(pictureChannel));
    	this.add(picLabelC);
    	picLabelC.setBorder(BorderFactory.createMatteBorder(3, 0, 3, 0, Color.BLACK));
  
    	JPanel panelDown = new JPanel();
    	panelDown.setLayout(new BorderLayout());
        panelDisp2 = new JPanel();
        panelDisp2.setBorder(BorderFactory.createTitledBorder("Alice & Bob informazioni"));
        panelDisp2.setLayout(new BorderLayout());
        paneletichette = new JPanel();
        paneletichette.setLayout(new GridLayout(13,1));
        paneletichette.add(new Label());
        paneletichette.add(new Label("Alice rawKey"));
        paneletichette.add(new Label("Alice basi"));
        paneletichette.add(new Label("Alice fotoni"));
        paneletichette.add(new Label("Eve fotoni"));
        paneletichette.add(new Label("Bob basi"));
        paneletichette.add(new Label("Bob rawKey"));
        paneletichette.add(new Label("Alice sifitingKey"));
        paneletichette.add(new Label("Bob sifitingKey"));
        paneletichette.add(new Label("Alice checkBits"));
        paneletichette.add(new Label("Bob checkBits"));
        paneletichette.add(new Label("Alice distillationKey"));
        paneletichette.add(new Label("Bob distillationKey"));
        panelDisp2.add(paneletichette, BorderLayout.WEST);
        JScrollPane pane = new JScrollPane(panelDisp2,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,  
        		   ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        panelDown.add(pane, BorderLayout.CENTER);
        
        this.add(panelDown);
	}
	
	public void setEveImage(){
		if(frame.sf.eveYes.isSelected()){
			pictureEve = null;
	        
	    	try {
	    		URL url = getClass().getResource("/images/Eve.png");
	    		pictureEve = ImageIO.read(url);
		
			} catch (IOException e) {
				e.printStackTrace();
			}
	    	
	    	picLabelE = new JLabel(new ImageIcon(pictureEve));
	    	panelEve = new JPanel();
			panelEve.setLayout(new FlowLayout());
			panelEve.add(picLabelE);
		    labelBaseEve = new JLabel();
		    panelEve.add(labelBaseEve);
		    panelUp.add(panelEve, BorderLayout.SOUTH);
	    	this.revalidate();
		}else{
			panelUp.remove(panelEve);
			this.revalidate();
		}
		
	}
	
	public void setButtonPlay(){
		
		 play=new JButton();    
		 URL url = getClass().getResource("/images/play.png");
	     Icon icon=new ImageIcon(url);
	     play.setIcon(icon);
	     play.addActionListener(this);
	     panelDisp1.add(play);
	     this.revalidate();
	}
	
	public void startPhase1(){
		EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                }
                Component[] components = panelDisp2.getComponents();
            	JPanel panel = (JPanel)components[1];
            	Component[] components2 = panel.getComponents();
            	for(int i=0; i<frame.Qubits; i++){
            		JTextField f = (JTextField) components2[i+frame.Qubits];
            		f.setText(""+frame.sender.getRawKey().get(i));
            		f = (JTextField) components2[i+(frame.Qubits*2)];
            		f.setText(""+frame.sender.getArrayBasiSender().get(i));
            	}
            	frame.cf.labelDisplay1.setText(frame.fase2);
        	    frame.cf.labelDisplay1.setFont(new Font("Serif", Font.PLAIN, 30));
        	    play.setEnabled(true);
        	    revalidate();
            }
        });
	}
	
	public void startPhase2(){
		EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                }
                animationFotoni = new AnimationFotoni(ChannelFrame.this, frame.sender.getArrayFotoni(),1,1);
                ChannelFrame.this.remove(picLabelC);
                ChannelFrame.this.add(animationFotoni, 2,1);
                frame.sf.slider.setEnabled(true);
                
            }
        });
	}
	

	
	public void startPhase3(){
		EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                }
                animationClassicChannel = new AnimationClassicChannel(ChannelFrame.this,frame.receiver.getArrayBasiReceiver(), frame.sender.getArrayBasiSender(),frame.sender.getArrayCheck(), -1,1);
                ChannelFrame.this.remove(animationFotoni);
                ChannelFrame.this.add(animationClassicChannel, 2,1);
                frame.sf.slider.setEnabled(true);
                frame.sf.slider.setEnabled(true);
            }
        });
	}
	
	public void startPhase4(){
		EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                }
                ChannelFrame.this.remove(animationClassicChannel);
                animationClassicChannel = new AnimationClassicChannel(ChannelFrame.this,frame.sender.getArrayBasiSender(),frame.receiver.getArrayBasiReceiver(), frame.receiver.getArrayCheck(), 1,1);
                ChannelFrame.this.add(animationClassicChannel, 2,1);
                frame.sf.slider.setEnabled(true);
            }
        });
	}
	
	public void startPhase5(){
		EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                }
                
                Component[] components = panelDisp2.getComponents();
            	JPanel panel = (JPanel)components[1];
            	Component[] components2 = panel.getComponents();
            	for(int i=0; i<frame.Qubits; i++){
            		JTextField f = (JTextField) components2[i+(frame.Qubits*7)];
            		if(frame.sender.getKeySifting().get(i) == null){
            			f.setBackground(Color.gray);
            			f = (JTextField) components2[i+(frame.Qubits*8)];
            			f.setBackground(Color.gray);
            			continue;
            			
            		}
            		f.setText(""+frame.sender.getKeySifting().get(i));
            		f = (JTextField) components2[i+(frame.Qubits*8)];
            		f.setText(""+frame.receiver.getKeySifting().get(i));
            	}
            	frame.rf.counterLabelSender.setText(""+frame.sender.getKeySifting().size());
            	frame.rf.counterLabelReceiver.setText(""+frame.receiver.getKeySifting().size());;
            	 frame.sf.slider.setEnabled(false);
            	   frame.cf.play.setEnabled(true);
            	   frame.cf.labelDisplay1.setText(frame.fase6); 
            		  frame.rf.labelEtSender.setText("Bit inviati: "); 
            		 frame.rf.labelEtReceiver.setText("Bit ricevuti: ");
            		 frame.rf.counterLabelReceiver.setText("0");
              	 frame.rf.counterLabelSender.setText("0");
            	revalidate();
            }
        });
	}
	
	public void startPhase6(){
		EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                }
                
               ChannelFrame.this.remove(animationClassicChannel);
                
               animationBit = new AnimationBit(ChannelFrame.this,frame.sender.getArrayCheckBitSender(), 1,1);
              
                ChannelFrame.this.add(animationBit, 2,1);
               frame.sf.slider.setEnabled(true);

            }
        });
	}
	
	public void startPhase7(){
		EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                }
                
               ChannelFrame.this.remove(animationBit);
                
               animationBit = new AnimationBit(ChannelFrame.this,frame.receiver.getArrayCheckBitReceiver(), -1,1);
              
                ChannelFrame.this.add(animationBit, 2,1);
               frame.sf.slider.setEnabled(true);

            }
        });
	}
	
	public void startPhase8(){
		EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                }
                
                
                Component[] components = panelDisp2.getComponents();
            	JPanel panel = (JPanel)components[1];
            	Component[] components2 = panel.getComponents();
            	for(int i=0; i<frame.Qubits; i++){
            		JTextField f = (JTextField) components2[i+(frame.Qubits*9)];
            		JTextField f2 = (JTextField) components2[i+(frame.Qubits*10)];
            		if(f.getBackground() == Color.gray){
            			continue;
            		}
            		if(f.getText().equals(f2.getText())){
            			components2[i + (frame.Qubits*9)].setBackground(Color.green);
            			components2[i + (frame.Qubits*10)].setBackground(Color.green);
            		}	
            	    else{
            	    	components2[i + (frame.Qubits*9)].setBackground(Color.red);
            	    	components2[i + (frame.Qubits*10)].setBackground(Color.red);
            	    }         		
            	}
            	
            	try {
					frame.sender.creationDistillationKey();
					frame.receiver.creationDistillationKey();
					for(int i=0; i<frame.sender.getNQubits(); i++){
	            		JTextField f = (JTextField) components2[i+(frame.Qubits*11)];
	            		JTextField f2 = (JTextField) components2[i+(frame.Qubits*12)];
	            		if(frame.sender.getKeyDistillation().get(i) == null){
	            			f.setBackground(Color.gray);
	            			f2.setBackground(Color.gray);
	            			continue;
	            		}
	            		f.setText(""+frame.sender.getKeyDistillation().get(i));
	            		f2.setText(""+frame.receiver.getKeyDistillation().get(i));
	            	}
					
					frame.rf.counterLabelSender.setText(""+frame.sender.getKeyDistillation().size()); 
					frame.rf.counterLabelReceiver.setText(""+frame.receiver.getKeyDistillation().size()); 
					if(Engine.compareKey(frame.sender.getKeyDistillation(), frame.receiver.getKeyDistillation())){
						if(frame.flagEve == false)JOptionPane.showMessageDialog(frame, "Chiave Segreta sicura\n");
						else JOptionPane.showMessageDialog(frame, "Chiave erronamente considerata sicura \n Eve non � stato rilevato", "Errore",JOptionPane.ERROR_MESSAGE);
					}
							
					else JOptionPane.showMessageDialog(frame, "Chiave erronamente considerata sicura \n Eve non � stato rilevato", "Errore",JOptionPane.ERROR_MESSAGE);
				} catch (Exception e) {
					
					JOptionPane.showMessageDialog(frame, "Chiave compromessa \n", "Errore",JOptionPane.ERROR_MESSAGE);
	
				}
            	revalidate();
            	
            	 ChannelFrame.this.remove(animationBit);
            	 JPanel panelButton = new JPanel();
            	 panelButton.setLayout(new BorderLayout());
            	 showInfo = new JButton("Mostra Info");
            	 panelButton.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(100, 100, 100, 100), new EtchedBorder()));
            	 panelButton.add(showInfo, BorderLayout.CENTER);
            	 showInfo.addActionListener(ChannelFrame.this);
                 ChannelFrame.this.add(panelButton, 2,1);
            }
        });
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource() == play){
			
			switch(frame.numberPhase){
			case 0: frame.cf.startPhase1(); frame.protocollo.codifyAndSend(); play.setEnabled(false); frame.numberPhase++; break;
			case 1: frame.cf.startPhase2(); frame.protocollo.read(); play.setEnabled(false); frame.numberPhase++; break;
			case 2: frame.cf.startPhase3(); frame.protocollo.sifting(); play.setEnabled(false); frame.numberPhase++; break;
			case 3: frame.cf.startPhase4(); play.setEnabled(false); frame.numberPhase++; break;
			case 4: frame.cf.startPhase5(); play.setEnabled(false); frame.numberPhase++; break;
			case 5: frame.cf.startPhase6(); frame.protocollo.distillation(); play.setEnabled(false); frame.numberPhase++; break;
			case 6: frame.cf.startPhase7(); play.setEnabled(false); frame.numberPhase++; break;
			case 7: frame.cf.startPhase8(); play.setEnabled(false); frame.numberPhase++; break;
			
			}    
		}
		
		if(arg0.getSource() == showInfo){
			JOptionPane.showMessageDialog(frame, ""+frame.protocollo.info());
		}
		
	}

}
