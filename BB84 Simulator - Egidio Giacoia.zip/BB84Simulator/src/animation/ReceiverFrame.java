package animation;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;

import org.w3c.dom.css.Counter;

public class ReceiverFrame extends JPanel implements ActionListener{

	protected MainFrame frame;
	protected JLabel base;
	protected JLabel counterLabelSender;
	protected JLabel counterLabelReceiver;
	protected JLabel labelEtSender;
	protected JLabel labelEtReceiver;
	protected String colorChannelClassic = "#ffffb3";
	protected String colorChannelQuantum = "#80e5ff";
	
	
	public ReceiverFrame(MainFrame frame){
		this.frame = frame;
		this.setLayout(new GridLayout(3,1));
		
		JPanel controlPanelUp = new JPanel();
		controlPanelUp.setBorder(new CompoundBorder(new EmptyBorder(30, 30, 30, 30), BorderFactory.createTitledBorder("Bob Basi")));
        BufferedImage pictureReceiver = null;
        
    	try {
    		URL url = getClass().getResource("/images/Bob2.png");
			pictureReceiver = ImageIO.read(url);
	
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	JLabel picLabelR = new JLabel(new ImageIcon(pictureReceiver));
    	picLabelR.setBorder(BorderFactory.createMatteBorder(3, 0, 3, 3, Color.BLACK));
    	this.add(controlPanelUp);
    	  
    	base = new JLabel();
        controlPanelUp.add(base);
    	this.add(picLabelR);
    	

        JPanel controlPanelDown = new JPanel();
        JPanel panelContainer = new JPanel();
        panelContainer.setLayout(new GridLayout(4,2));
        
        labelEtSender =  new JLabel("Fotoni Inviati: ");
        panelContainer.add(labelEtSender);
        counterLabelSender = new JLabel("0");
        counterLabelSender.setFont(new Font("Serif", Font.PLAIN, 30));
        counterLabelSender.setHorizontalAlignment(JTextField.RIGHT);
        panelContainer.add(counterLabelSender);
        
        labelEtReceiver =  new JLabel("Fotoni Ricevuti: ");
        panelContainer.add(labelEtReceiver);
        counterLabelReceiver = new JLabel("0");
        counterLabelReceiver.setHorizontalAlignment(JTextField.RIGHT);
        counterLabelReceiver.setFont(new Font("Serif", Font.PLAIN, 30));
        panelContainer.add(counterLabelReceiver);
        JPanel colorQ = new JPanel();
        colorQ.setBackground(Color.decode(colorChannelQuantum));
        panelContainer.add(colorQ);
        panelContainer.add(new JLabel("  Canale Quantistico"));
        JPanel colorC = new JPanel();
        colorC.setBackground(Color.decode(colorChannelClassic));
        panelContainer.add(colorC);
        panelContainer.add(new JLabel("  Canale Classico"));
        
        
         
        controlPanelDown.add(panelContainer);
        controlPanelDown.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(30, 30, 30, 30), new EtchedBorder()));
        
        
        this.add(controlPanelDown);
        
      
      
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
	
	}
}
