package animation;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.Timer;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import coding.Channel;
import coding.ChannelEavesdropper;
import coding.Eavesdropper;
import coding.ProtocolloBB84;
import coding.Receiver;
import coding.Sender;

public class SenderFrame extends JPanel implements ActionListener, ChangeListener{
	protected JButton confirm;
	protected JTextField textQubits;
	protected MainFrame frame;
	protected JSlider slider;
	protected JSlider sliderEve;
	protected JLabel base;
	protected JRadioButton eveYes;
	protected JRadioButton eveNot;
	protected JSlider sliderBit;
	
	

	
	public SenderFrame(MainFrame frame){
		this.frame = frame;
		this.setLayout(new GridLayout(3,1));
		
		JPanel controlPanelUp = new JPanel();
		controlPanelUp.setBorder(new CompoundBorder(new EmptyBorder(30, 30, 30, 30), BorderFactory.createTitledBorder("Alice Basi")));
        BufferedImage pictureSender = null;
        
    	try {
    		URL url = getClass().getResource("/images/Alice2.png");
			pictureSender = ImageIO.read(url);
	
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	JLabel picLabelS = new JLabel(new ImageIcon(pictureSender));
    	picLabelS.setBorder(BorderFactory.createMatteBorder(3, 3, 3, 0, Color.BLACK));
    	this.add(controlPanelUp);
    	  
    	base = new JLabel();
        controlPanelUp.add(base);
    	this.add(picLabelS);
    	

        JPanel controlPanelDown = new JPanel();
        controlPanelDown.setLayout(new GridLayout(4,1));
        
        JPanel panelBit = new JPanel();        
        //panelBit.setLayout(new FlowLayout());
        panelBit.setLayout(new BorderLayout());
        panelBit.add(new JLabel("N� Qubit"), BorderLayout.WEST);
        textQubits = new JTextField(10);
        panelBit.add(textQubits, BorderLayout.CENTER);
        confirm = new JButton("Conferma");
        confirm.addActionListener(this);
        panelBit.add(confirm, BorderLayout.EAST);
        
        controlPanelDown.add(panelBit);
        
        JPanel panelEve = new JPanel();
        panelEve.setLayout(new FlowLayout());
        eveYes = new JRadioButton("Si");
        eveNot = new JRadioButton("No");
        eveNot.setSelected(true);

           //Group the radio buttons.
        ButtonGroup group = new ButtonGroup();
        group.add(eveNot);
        group.add(eveYes);
        eveYes.addActionListener(this);
        eveNot.addActionListener(this);
        panelEve.add(new JLabel("Abilita Eve: "));
        panelEve.add(eveYes);
        panelEve.add(eveNot);
        panelBit.add(panelEve, BorderLayout.SOUTH);
        //controlPanelDown.add(panelEve);
        
        JPanel panelBitCompare = new JPanel();
        panelBitCompare.setLayout(new BorderLayout());
        panelBitCompare.add(new JLabel("Regola % numero bit da controllare"), BorderLayout.NORTH);
        sliderBit = new JSlider(JSlider.HORIZONTAL, 0, 50, 50);
        sliderBit.setMinorTickSpacing(1);
        sliderBit.setMajorTickSpacing(10);
        sliderBit.setPaintTicks(true);
        sliderBit.setPaintLabels(true);
        sliderBit.setLabelTable(sliderBit.createStandardLabels(10));
        panelBitCompare.add(sliderBit, BorderLayout.CENTER);
        controlPanelDown.add(panelBitCompare);
        
        JPanel panelEveLevel = new JPanel();
        panelEveLevel.setLayout(new BorderLayout());
        panelEveLevel.add(new JLabel("Regola livello eavesdropper"), BorderLayout.NORTH);
       /* sliderEve = new JSlider(JSlider.HORIZONTAL, 0, 10, 5);
        sliderEve.setMinorTickSpacing(1);
        sliderEve.setMajorTickSpacing(5);
        sliderEve.setPaintTicks(true);
        sliderEve.setPaintLabels(true);
        sliderEve.setLabelTable(sliderEve.createStandardLabels(5));*/
        sliderEve = new JSlider(1,10);
        sliderEve.setMinorTickSpacing(1);
        //sliderEve.setMajorTickSpacing(5);
        sliderEve.setPaintTicks(true);
        sliderEve.setPaintLabels(true);
        sliderEve.setLabelTable(sliderEve.createStandardLabels(1));
        sliderEve.setEnabled(false);
        panelEveLevel.add(sliderEve, BorderLayout.CENTER);
        controlPanelDown.add(panelEveLevel);
        
        JPanel panelVelocita = new JPanel();
        panelVelocita.setLayout(new BorderLayout());
        panelVelocita.add(new JLabel("Regola velocit� animazione"), BorderLayout.NORTH);
        slider = new JSlider(JSlider.HORIZONTAL, 0, 20, 10);
        slider.setMinorTickSpacing(1);
        slider.setMajorTickSpacing(10);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        slider.setLabelTable(slider.createStandardLabels(10));
        
        slider.addChangeListener(this);
        slider.setEnabled(false);
        panelVelocita.add(slider, BorderLayout.CENTER);
        controlPanelDown.add(panelVelocita);
        
        
        controlPanelDown.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(0, 0, 0, 0), new EtchedBorder()));
        this.add(controlPanelDown);
        
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	
		if(e.getSource() == eveYes){
			eveYes.setSelected(true);
			eveNot.setSelected(false);
			frame.cf.setEveImage();
			sliderEve.setEnabled(true);
		}
		
		if(e.getSource() == eveNot){
			eveYes.setSelected(false);
			eveNot.setSelected(true);
			frame.cf.setEveImage();
			sliderEve.setEnabled(false);
		}
		
		if(e.getSource() == confirm){
			
			try {
			     frame.Qubits = Integer.parseInt(textQubits.getText());
			}
			catch (NumberFormatException exc) {
				JOptionPane.showMessageDialog(frame, "Input invalido\n", "Errore",JOptionPane.ERROR_MESSAGE);
			     return;
			}
			
			frame.sender = new Sender(frame.Qubits);
			frame.receiver = new Receiver();
			Channel channel;
			
			if(eveNot.isSelected())
				frame.channel = new Channel(frame.sender,frame.receiver, sliderBit.getValue());
			else {
				frame.eve = new Eavesdropper(sliderEve.getValue());
				frame.channel = new ChannelEavesdropper(frame.sender,frame.receiver,frame.eve, sliderBit.getValue());
				frame.flagEve = true;
			}
			
			frame.protocollo = new ProtocolloBB84(frame.channel);
			JPanel panel = new JPanel();
			panel.setLayout(new GridLayout(13, frame.Qubits));
			for(int i=0; i<13; i++){
				 for(int j=0; j<frame.Qubits; j++){
					 if(i == 0) {
					 		JTextField tx = new JTextField("",4);
				            panel.add(tx);
				            int x = j+1;
				            tx.setText(""+x);
				            tx.setHorizontalAlignment(JTextField.CENTER);
				            tx.setEditable(false);
				            continue;
					 	}
			            JTextField tx = new JTextField("",1);
			            panel.add(tx);
			            tx.setHorizontalAlignment(JTextField.CENTER);
			            tx.setEditable(false);
			            tx.setBackground(Color.white);
				 }
		    }

			if(frame.flagEve == true){
				JPanel panel2 = new JPanel();
				panel2.setLayout(new GridLayout(5, frame.Qubits));
				for(int i=0; i<5; i++){
					 for(int j=0; j<frame.Qubits; j++){
						 	if(i == 0) {
						 		JTextField tx = new JTextField("",4);
					            panel2.add(tx);
					            int x = j+1;
					            tx.setText(""+x);
					            tx.setHorizontalAlignment(JTextField.CENTER);
					            tx.setEditable(false);
					            continue;
						 	}
				            JTextField tx = new JTextField("",1);
				            panel2.add(tx);
				            tx.setHorizontalAlignment(JTextField.CENTER);
				            tx.setEditable(false);
				            tx.setBackground(Color.white);
					 }
			    }
				
				frame.cf.panelUp.remove(frame.cf.panelDispEve);
				frame.cf.panelDispEve = new JPanel();
				frame.cf.panelDispEve.setLayout(new GridLayout(1,5));
				
				frame.cf.panelInfoEve = new JPanel();
				frame.cf.panelInfoEve.setBorder(BorderFactory.createTitledBorder("Eve informazioni"));
				frame.cf.panelInfoEve.setLayout(new BorderLayout());
				frame.cf.paneletichetteEve = new JPanel();
				frame.cf.paneletichetteEve.setLayout(new GridLayout(5,1));
				frame.cf.paneletichetteEve.add(new Label());
				frame.cf.paneletichetteEve.add(new Label("Alice fotoni"));
				frame.cf.paneletichetteEve.add(new Label("Eve basi"));
				frame.cf.paneletichetteEve.add(new Label("Eve rawKey"));
				frame.cf.paneletichetteEve.add(new Label("Eve fotoni"));
				
			      
				frame.cf.panelInfoEve.add(frame.cf.paneletichetteEve, BorderLayout.WEST);
				frame.cf.panelInfoEve.add(panel2,BorderLayout.CENTER);
				JScrollPane pane = new JScrollPane(frame.cf.panelInfoEve,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,  
		        		   ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				frame.cf.panelDispEve.add(pane);
				
				frame.cf.panelUp.remove(frame.cf.panelEve);
				frame.cf.picLabelE = new JLabel(new ImageIcon(frame.cf.pictureEve));
				frame.cf.panelDispEve.add(frame.cf.picLabelE);
			
				JPanel baseEve = new JPanel();
				baseEve.setBorder(new CompoundBorder(new EmptyBorder(5, 5, 5, 5), BorderFactory.createTitledBorder("Eve Basi")));
				//baseEve.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(5, 5, 5, 5), new EtchedBorder()));
				frame.cf.labelBaseEve = new JLabel();
				baseEve.add(frame.cf.labelBaseEve);
				frame.cf.panelDispEve.add(baseEve);
				
				sliderEve.setEnabled(false);
				sliderBit.setEnabled(false);
				
		    	frame.cf.panelUp.add(frame.cf.panelDispEve, BorderLayout.CENTER);
	
			}
			
		     frame.cf.panelDisp2.add(panel, BorderLayout.CENTER);
		        
		        confirm.setEnabled(false);
		        textQubits.setEnabled(false);
		        eveNot.setEnabled(false);
		        eveYes.setEnabled(false);
		        frame.cf.panelDisp2.revalidate();
		        
		        frame.cf.labelDisplay1.setText(frame.fase1);
		        frame.cf.labelDisplay1.setFont(new Font("Serif", Font.PLAIN, 30));
		        frame.cf.setButtonPlay();
		        JOptionPane.showMessageDialog(frame, ""+frame.protocollo.infoProbabilitaStimata());
		}
	}
	
	
	
	public void stateChanged(ChangeEvent e) {
		JSlider source = (JSlider)e.getSource();
        if (!source.getValueIsAdjusting()) {
            int fps = (int)source.getValue();
         
            if(fps > 10) {
            	if(frame.numberPhase <=2){
            		fps = (fps * 30) -10; frame.cf.animationFotoni.changeFaseter(fps);
            	}else if(frame.numberPhase<=5){
            		fps = (fps * 30) -10; 
            		frame.cf.animationClassicChannel.changeFaseter(fps);
            	}else{
            		fps = (fps * 30) -10; 
            		frame.cf.animationBit.changeFaseter(fps);
            	}
            }
            else if(fps < 10 || fps > 0){
            	if(frame.numberPhase <=2){
            		fps = (10 - fps);
                	fps = fps *10; frame.cf.animationFotoni.changeLower(fps);
            	}else if(frame.numberPhase<=5){
            		fps = (fps * 10) -10; 
            		frame.cf.animationClassicChannel.changeLower(fps);
            		
            	}else{
            		fps = (fps * 10) -10; 
            		frame.cf.animationBit.changeLower(fps);
            	}
            	
            }
            
        }    
	}
}
