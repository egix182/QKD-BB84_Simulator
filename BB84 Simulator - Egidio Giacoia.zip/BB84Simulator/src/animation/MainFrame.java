package animation;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import coding.Channel;
import coding.Eavesdropper;
import coding.ProtocolloBB84;
import coding.Receiver;
import coding.Sender;

public class MainFrame extends JFrame{
	
	protected  SenderFrame sf;
	protected  ReceiverFrame rf;
	protected  ChannelFrame cf;
	
	protected Sender sender;
	protected Receiver receiver;
	protected Channel channel;
	protected Eavesdropper eve;
	protected ProtocolloBB84 protocollo;
	protected int Qubits;
	protected boolean flagEve = false;

	
	protected int numberPhase = 0;
	protected String fase0 = "Fase 0 - Inizializzazione";
	protected String fase1 = "Fase 1 - Alice generazione raw key e basi";
	protected String fase2 = "Fase 2 - Alice invia i fotoni e Bob esegue la lettura";
	protected String fase3 = "Fase 3 - Bob invia le sue basi ad Alice";
	protected String fase4 = "Fase 4 - Alice Invia le sue basi a Bob";
	protected String fase5 = "Fase 5 - Generazione della sifting key";
	protected String fase6 = "Fase 6 - Alice invia i suoi bit di controllo a Bob";
	protected String fase7 = "Fase 7 - Bob invia i suoi bit di controllo ad Alice";
	protected String fase8 = "Fase 8 - Generazione della distillation key";
		
	
	public MainFrame(){
		JFrame frame = new JFrame("BB84 Simulator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH); 
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        cf = new ChannelFrame(this);
        sf = new SenderFrame(this);
        rf = new ReceiverFrame(this);
               
        frame.add(sf, BorderLayout.WEST);
        frame.add(rf, BorderLayout.EAST);
        frame.add(cf, BorderLayout.CENTER);
        frame.setBackground(Color.WHITE);
    
	}
	
	

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                }
            	new MainFrame();
            }
        });
	

	}

}
