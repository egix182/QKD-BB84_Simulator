package animation;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Iterator;
import java.util.TreeMap;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;

import coding.Engine;

public class AnimationBit extends JPanel implements ActionListener{
	private BufferedImage image;
    private int xPos = 0;
    private int fast = 1;
    private int direction = 1;
    private ChannelFrame parent;
    private TreeMap<Integer, Integer> arrayBit;
    private int currentIndex  = 0;
    private Timer t;
    private Iterator arrayKey;
    private int timer;
    private boolean flag = false;
    private Color colorBefore;
    private URL url;

    
    public AnimationBit(ChannelFrame parent, TreeMap<Integer, Integer> arrayBit, 
    		int direction, int timer) {
        this.parent = parent;
        this.setBorder(BorderFactory.createMatteBorder(3, 0, 3, 0, Color.BLACK));
        this.setBackground(Color.decode(parent.frame.rf.colorChannelClassic));
        this.parent.revalidate();
        this.direction = direction;
        if(direction == -1) fast = -1;
        this.arrayBit = arrayBit; 
        this.arrayKey = parent.frame.sender.getArrayFotoni().keySet().iterator();

        this.timer = timer;
        t = new Timer(timer, this);
        loadImage();
    }
    
 
    
    public void checkDirection(){
    	if(image != null){
    		if(direction == -1){
    	    	xPos = parent.getWidth() - image.getWidth();}
    	    	else xPos = 0;
    	}
    }
    
    public void loadImage(){
    	try {
    	   if(!arrayKey.hasNext()){ exit(); return;}
           currentIndex = (Integer) arrayKey.next();
           if(arrayBit.get(currentIndex) != null){
   			int b = arrayBit.get(currentIndex);
           	   
              	if(b == 1){
            		url = getClass().getResource("/images/Bit1.png");
              		image = ImageIO.read(url);
              	}
              	if(b == 0){
            		url = getClass().getResource("/images/Bit0.png");
              		image = ImageIO.read(url);
              	}
   		   }
           else image = null;
   			  
        		
        	checkDirection();
        	display();
        	t.setRepeats(true);
            t.setCoalesce(true);
            t.start();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public void reset(){
    	t.stop();
    	checkDirection();
    	loadImage();
    }
    
   
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        if(image != null){
        	 int y = (getHeight()/2) - (image.getHeight()/2);
             if(flag == false)
             	g.drawImage(image, xPos, y, this);
             else 
             	g.drawImage(null, 0, 0, this);
        }
       
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
    	
    	if(image != null){
    		xPos += fast;
            if(direction == 1){
            	 if (!(xPos + image.getWidth() > getWidth())) 
                 	repaint();
                 else{
                	remove();
         			reset();        			
                 }
            }

            if(direction == -1){
            	if(xPos <0) {remove(); reset();}
            	else repaint();
            }
    	}
    	
    	else { remove(); reset();}
        
    }
    
    public void display(){
    	if(image != null){
    		int indexFotone = Integer.parseInt(parent.frame.rf.counterLabelSender.getText()) +1;
    		parent.frame.rf.counterLabelSender.setText(""+ indexFotone);
    	}
    	
    	Component[] components = parent.panelDisp2.getComponents();
    	JPanel panel = (JPanel)components[1];
    	Component[] components2 = panel.getComponents();
    	
    	if(direction == 1){
    		colorBefore =components2[currentIndex + (parent.frame.sender.getNQubits()*7)].getBackground();
        	components2[(currentIndex)+(parent.frame.sender.getNQubits()*7)].setBackground(Color.yellow);
        	JTextField f = (JTextField) components2[(currentIndex)+(parent.frame.sender.getNQubits()*9)];
           	if(arrayBit.get(currentIndex) == null){
           			f.setBackground(Color.gray);
           			return;
           	}else f.setText(""+arrayBit.get(currentIndex));
    	}else{
    		colorBefore =components2[currentIndex + (parent.frame.sender.getNQubits()*8)].getBackground();
        	components2[(currentIndex)+(parent.frame.sender.getNQubits()*8)].setBackground(Color.yellow);
        	JTextField f = (JTextField) components2[(currentIndex)+(parent.frame.sender.getNQubits()*10)];
           	if(arrayBit.get(currentIndex) == null){
           			f.setBackground(Color.gray);
           			return;
           	}else f.setText(""+arrayBit.get(currentIndex));
    	}
    	
       
    }
    
    public void remove(){
    	if(image != null){
    		int indexFotone = Integer.parseInt(parent.frame.rf.counterLabelSender.getText()); 
        	parent.frame.rf.counterLabelReceiver.setText(""+indexFotone); 
    	}
    	
    	Component[] components = parent.panelDisp2.getComponents();
    	JPanel panel = (JPanel)components[1];
    	Component[] components2 = panel.getComponents();
    	if(direction == 1){
    		components2[(currentIndex)+(parent.frame.sender.getNQubits()*7)].setBackground(colorBefore);
    	}else{
    		components2[(currentIndex)+(parent.frame.sender.getNQubits()*8)].setBackground(colorBefore);
    	}
    }
    
    
    
    public void changeLower(int i){
      	t.setDelay(i);
      	if(direction == 1) fast = 1;
      	else fast = -1;
    }
    
    public void changeFaseter(int i){
    	if(direction == 1) fast = i;
    	else fast = -i;
      	t.setDelay(1);
    }
    
    private void exit(){
       t.stop(); flag = true; repaint(); 
 	   parent.frame.rf.base.setIcon(null);
 	   parent.frame.sf.base.setIcon(null);  
 	   parent.frame.sf.slider.setValue(10); 
  	   parent.frame.sf.slider.setEnabled(false);
  	   parent.frame.cf.play.setEnabled(true);
   	   if(direction == 1){
   		  parent.frame.cf.labelDisplay1.setText(parent.frame.fase7); 
   		  parent.frame.rf.counterLabelReceiver.setText("0");
     	  parent.frame.rf.counterLabelSender.setText("0");
     	 repaint(); 
   	   }
   	   else {
   		   parent.frame.cf.labelDisplay1.setText(parent.frame.fase8);
   		  parent.frame.rf.labelEtSender.setText("Lunghezza Chiave Alice: "); 
   		  parent.frame.rf.labelEtReceiver.setText("Lunghezza Chiave Bob: ");
   		   parent.frame.rf.counterLabelReceiver.setText("0");
   	  	   parent.frame.rf.counterLabelSender.setText("0");
   	  	repaint(); 
   	   }
      }
}
