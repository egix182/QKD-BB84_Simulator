package animation;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;

import coding.Engine;
import coding.Fotone;

public class AnimationFotoni extends JPanel implements ActionListener{
	private BufferedImage fotone;
    private int xPos = 0;
    private int fast = 1;
    private int direction = 1;
    private ChannelFrame parent;
    private TreeMap<Integer, Fotone> arrayFotoni;
    private int currentIndex  = 0;
    private Timer t;
    private Iterator arrayKey;
    private int timer;
    private boolean flag = false;
    private boolean flagIntercept = false;
    private URL url;
  
    
    public AnimationFotoni(ChannelFrame parent, TreeMap<Integer,Fotone> arrayFotoni, int direction, int timer) {
        this.parent = parent;
        this.setBorder(BorderFactory.createMatteBorder(3, 0, 3, 0, Color.BLACK));
        this.setBackground(Color.decode(parent.frame.rf.colorChannelQuantum));
        this.parent.revalidate();
        this.arrayFotoni = arrayFotoni ;
        this.direction = direction;
        arrayKey = arrayFotoni.keySet().iterator();
        this.timer = timer;
        t = new Timer(timer, this);
        loadImage();
    }
    
    public void checkDirection(){
    	if(direction == -1)
    	xPos = parent.getWidth() - fotone.getWidth();
    	else xPos = 0;
    }
    
    public void loadImage(){
    	try {
    	   if(!arrayKey.hasNext()){ exit();  return;}
           currentIndex = (Integer) arrayKey.next();
    	   char s = arrayFotoni.get(currentIndex).getSimbolo();
 		   int b = parent.frame.sender.getRawKey().get(currentIndex);
 		   BaseDefault base = BaseDefault.DIAGONALE;
 		   BufferedImage baseIcon = null;
 		   if(s == '\\' || s== '/') base = BaseDefault.DIAGONALE;
 		   if(s == '|' || s== '_') base = BaseDefault.RETTILINEA;
        	if(base.equals(base.DIAGONALE) && b == 0){
        		url = getClass().getResource("/images/Diagonale_0.png");
        		fotone = ImageIO.read(url);
        		url = getClass().getResource("/images/BaseD.png");
        		baseIcon = ImageIO.read(url);;
        		parent.frame.sf.base.setIcon(new ImageIcon(baseIcon));
        	}
        		
        	if(base.equals(base.DIAGONALE) && b == 1){
        		url = getClass().getResource("/images/Diagonale_1.png");
        		fotone = ImageIO.read(url);
        		url = getClass().getResource("/images/BaseD.png");
        		baseIcon = ImageIO.read(url);;
        		parent.frame.sf.base.setIcon(new ImageIcon(baseIcon));
        	}
        		
        	if(base.equals(base.RETTILINEA) && b == 0){
        		url = getClass().getResource("/images/Rettilinea_0.png");
        		fotone = ImageIO.read(url);
        		url = getClass().getResource("/images/BaseR.png");
        		baseIcon = ImageIO.read(url);;
        		parent.frame.sf.base.setIcon(new ImageIcon(baseIcon));
        	}
        	if(base.equals(base.RETTILINEA) && b == 1){
        		url = getClass().getResource("/images/Rettilinea_1.png");
        		fotone = ImageIO.read(url);
        		url = getClass().getResource("/images/BaseR.png");
        		baseIcon = ImageIO.read(url);;
        		parent.frame.sf.base.setIcon(new ImageIcon(baseIcon));
        	}
        	
        	if(parent.frame.flagEve)checkEve();
        	checkDirection();
        	display();
        	t.setRepeats(true);
            t.setCoalesce(true);
            t.start();
           
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public void reset(){
    	t.stop();
    	checkDirection();
    	loadImage();
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        
        int y = (getHeight()/2) - (fotone.getHeight()/2);
        if(flag == false)
        	g.drawImage(fotone, xPos, y, this);
        else 
        	g.drawImage(null, 0, 0, this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
    	
        xPos += fast;
        if(direction == 1){
        	 if (!(xPos + fotone.getWidth() > getWidth())) {
        		 if(xPos+fotone.getWidth() >= (this.getWidth()/2)){
        			 if(flagIntercept == true)
        			 {
        				 changeFotone();
        			 }
        		 }
        		 repaint();
        	 }
             else{
            		 remove();
          			 reset();
             }
        }

        
        if(direction == -1){
        	if(xPos <0) reset();
        	else repaint();
        }
    }
    
    public void display(){
    	int indexFotone = Integer.parseInt(parent.frame.rf.counterLabelSender.getText()) +1;
    	parent.frame.rf.counterLabelSender.setText(""+ indexFotone);
    	
    	Component[] components = parent.panelDisp2.getComponents();
    	JPanel panel = (JPanel)components[1];
    	Component[] components2 = panel.getComponents();
    	components2[indexFotone-1+parent.frame.Qubits].setBackground(Color.yellow);
    	components2[(indexFotone-1)+(parent.frame.Qubits)*2].setBackground(Color.yellow);
    	components2[(indexFotone-1)+(parent.frame.Qubits)*3].setBackground(Color.yellow);
    	JTextField fotoneText = (JTextField)components2[(indexFotone-1)+(parent.frame.sender.getNQubits())*3];  	
    	fotoneText.setText(""+parent.frame.sender.getArrayFotoni().get(indexFotone-1).getSimbolo());
    	BufferedImage baseIcon=null;
		try {
			String base = Engine.getItemsBase(parent.frame.receiver.getArrayBasiReceiver());
			if(base.charAt(indexFotone-1) == 'D'){
				url = getClass().getResource("/images/BaseD.png");
				baseIcon = ImageIO.read(url);
			}else if(base.charAt(indexFotone-1) == 'R'){
				url = getClass().getResource("/images/BaseR.png");
				baseIcon = ImageIO.read(url);
			}
			parent.frame.rf.base.setIcon(new ImageIcon(baseIcon));
			
			if(parent.frame.flagEve){
				BufferedImage baseIconE = null;
				String baseE = Engine.getItemsBase(parent.frame.eve.getArrayBasiEve());
				if(baseE.charAt(currentIndex) == 'D'){
					url = getClass().getResource("/images/BaseDE.png");
					baseIconE = ImageIO.read(url);
				}else if(baseE.charAt(currentIndex) == 'R'){
					url = getClass().getResource("/images/BaseRE.png");
					baseIconE = ImageIO.read(url);
				}
				if(baseIconE !=null)
				parent.frame.cf.labelBaseEve.setIcon(new ImageIcon(baseIconE));
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
		
    	
    }
    
    public void remove(){
    	int indexFotoneRicevuti = Integer.parseInt(parent.frame.rf.counterLabelReceiver.getText()) +1;
    	parent.frame.rf.counterLabelReceiver.setText(""+ indexFotoneRicevuti);
    	int indexFotone = Integer.parseInt(parent.frame.rf.counterLabelSender.getText());
    	
    	Component[] components = parent.panelDisp2.getComponents();
    	JPanel panel = (JPanel)components[1];
    	Component[] components2 = panel.getComponents();
    	components2[indexFotone-1+parent.frame.Qubits].setBackground(Color.white);
    	components2[(indexFotone-1)+(parent.frame.Qubits)*2].setBackground(Color.white);
    	components2[(indexFotone-1)+(parent.frame.Qubits)*3].setBackground(Color.white);
    	
    	String base = Engine.getItemsBase(parent.frame.receiver.getArrayBasiReceiver());
    	String bit = Engine.getItems(parent.frame.receiver.getRawKey());
    	JTextField fbase = (JTextField)components2[(indexFotone-1)+(parent.frame.sender.getNQubits()*5)];
    	JTextField fbit = (JTextField)components2[(indexFotone-1)+(parent.frame.sender.getNQubits()*6)];
    	fbase.setText(""+base.charAt(indexFotone-1));
    	fbit.setText(""+bit.charAt(indexFotone-1));
    }
    
    public void changeLower(int i){
      	t.setDelay(i);
      	fast = 1;
    }
    
    public void changeFaseter(int i){
      	fast = i;
      	t.setDelay(1);
    }
    
    private void checkEve(){
    	char baseE = parent.frame.eve.getArrayBasiEve().get(currentIndex);
    	BufferedImage baseIcon = null;
    	try {
    		if(baseE != '?') {
        		flagIntercept = true;
        		url = getClass().getResource("/images/eye.png");
        		baseIcon = ImageIO.read(url);
            	parent.frame.cf.picLabelE.setIcon(new ImageIcon(baseIcon));
            	
        	}else
        	{
        		parent.frame.cf.labelBaseEve.setIcon(null);
        		url = getClass().getResource("/images/Eve.png");
        	 	baseIcon = ImageIO.read(url);
            	parent.frame.cf.picLabelE.setIcon(new ImageIcon(baseIcon));
        	}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    	this.revalidate();
    }
    
    private void changeFotone(){
    	t.stop();
    	
    
    	Component[] components = parent.panelInfoEve.getComponents();
    	JPanel panel = (JPanel)components[1];
    	Component[] components2 = panel.getComponents();
    	
    	JTextField fotoniAlice = (JTextField)components2[currentIndex+parent.frame.sender.getNQubits()];
    	fotoniAlice.setText(""+arrayFotoni.get(currentIndex).getSimbolo());
    	String baseString = Engine.getItemsBase(parent.frame.eve.getArrayBasiEve());
    	String bitString = Engine.getItemsBase(parent.frame.eve.getRawKey());
    	String fotoneString = Engine.getItemsFotone(parent.frame.eve.getArrayFotoni());
    	JTextField fbase = (JTextField)components2[currentIndex+(parent.frame.sender.getNQubits()*2)];
    	JTextField fbit = (JTextField)components2[currentIndex+(parent.frame.sender.getNQubits()*3)];
    	JTextField ffotone = (JTextField)components2[currentIndex+(parent.frame.sender.getNQubits()*4)];
    	fbase.setText(""+baseString.charAt(currentIndex));
    	fbit.setText(""+bitString.charAt(currentIndex));
    	ffotone.setText(""+fotoneString.charAt(currentIndex));
    	
    	components = parent.panelDisp2.getComponents();
    	panel = (JPanel)components[1];
    	components2 = panel.getComponents();
    	JTextField fx= (JTextField) components2[currentIndex+parent.frame.Qubits*4];
    	fx.setText(""+fotoneString.charAt(currentIndex));
    	
    	try{
    	   char s = parent.frame.eve.getArrayFotoni().get(currentIndex).getSimbolo();
  		   char b = parent.frame.eve.getRawKey().get(currentIndex);
  		   
  		   BaseDefault base = BaseDefault.DIAGONALE;
  		   BufferedImage baseIcon = null;
  		   if(s == '\\' || s== '/') base = BaseDefault.DIAGONALE;
  		   if(s == '|' || s== '_') base = BaseDefault.RETTILINEA;
        	if(base.equals(BaseDefault.DIAGONALE) && b == '0'){
        		url = getClass().getResource("/images/Diagonale_0.png");
        		fotone = ImageIO.read(url);
        	
        	}
        		
        	if(base.equals(BaseDefault.DIAGONALE) && b == '1'){
        		url = getClass().getResource("/images/Diagonale_1.png");
        		fotone = ImageIO.read(url);
        		
        	}
        		
        	if(base.equals(BaseDefault.RETTILINEA) && b == '0'){
        		url = getClass().getResource("/images/Rettilinea_0.png");
        		fotone = ImageIO.read(url);
        	}
        	if(base.equals(BaseDefault.RETTILINEA) && b == '1'){
        		url = getClass().getResource("/images/Rettilinea_1.png");
        		fotone = ImageIO.read(url);

        	}    	
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	
    	
    	
    	this.revalidate();
    	t.start();
    	this.flagIntercept = false;
    
    	
    }
    
    private void exit(){
    	if(parent.frame.flagEve == true){
    		BufferedImage baseIcon;
    		try {
    			url = getClass().getResource("/images/Eve.png");
    			baseIcon = ImageIO.read(url);
    			parent.frame.cf.picLabelE.setIcon(new ImageIcon(baseIcon));
    		} catch (IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    	}
    	
    	
       t.stop(); flag = true; repaint(); 
 	   parent.frame.sf.base.setIcon(null); parent.frame.rf.base.setIcon(null);
 	  if(parent.frame.flagEve == true)parent.frame.cf.labelBaseEve.setIcon(null);
 	   parent.frame.sf.slider.setValue(10);
 	   parent.frame.sf.slider.setEnabled(false);
 	   parent.frame.cf.labelDisplay1.setText(parent.frame.fase3);
 	   parent.frame.cf.play.setEnabled(true);
 	   parent.frame.rf.labelEtSender.setText("Basi Inviate");
 	   parent.frame.rf.labelEtReceiver.setText("Basi Ricevute");
 	   parent.frame.rf.counterLabelReceiver.setText("0");
 	   parent.frame.rf.counterLabelSender.setText("0");
    }

}

