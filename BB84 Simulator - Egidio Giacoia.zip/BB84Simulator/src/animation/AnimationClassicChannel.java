package animation;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Iterator;
import java.util.TreeMap;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

import coding.Engine;

public class AnimationClassicChannel extends JPanel implements ActionListener{
	private BufferedImage image;
    private int xPos = 0;
    private int fast = 1;
    private int direction = 1;
    private ChannelFrame parent;
    private TreeMap<Integer, Character> arrayBasi;
    private TreeMap<Integer, Character> arrayBasiOpposite;
    private TreeMap<Integer, Boolean> arrayCheck;
    private int currentIndex  = 0;
    private Timer t;
    private Iterator arrayKey;
    private int timer;
    private boolean flag = false;
    private Color colorBefore;
    private URL url;

    
    public AnimationClassicChannel(ChannelFrame parent, TreeMap<Integer, Character> arrayBasi, TreeMap<Integer, Character> arrayOpposite,
    		TreeMap<Integer, Boolean> arrayCheck,int direction, int timer) {
        this.parent = parent;
        this.setBorder(BorderFactory.createMatteBorder(3, 0, 3, 0, Color.BLACK));
        this.setBackground(Color.decode(parent.frame.rf.colorChannelClassic));
        this.parent.revalidate();
        this.direction = direction;
        if(direction == -1) fast = -1;
        this.arrayBasi = arrayBasi; 
        this.arrayKey = arrayBasi.keySet().iterator();
        this.arrayCheck = arrayCheck;
        this.arrayBasiOpposite = arrayOpposite;
        this.timer = timer;
        t = new Timer(timer, this);
        loadImage();
    }
    
 
    
    public void checkDirection(){
    	if(direction == -1){
    	xPos = parent.getWidth() - image.getWidth();}
    	else xPos = 0;
    }
    
    public void loadImage(){
    	try {
    	   if(!arrayKey.hasNext()){ exit(); return;}
           currentIndex = (Integer) arrayKey.next();
    	   char b = arrayBasi.get(currentIndex);
 
        	if(b == 'D'){
        		url = getClass().getResource("/images/BaseDO.png");
        		image = ImageIO.read(url);
        	}
        	if(b == 'R'){
        		url = getClass().getResource("/images/BaseRO.png");
        		image = ImageIO.read(url);
        	}
        		
        	checkDirection();
        	display();
        	t.setRepeats(true);
            t.setCoalesce(true);
            t.start();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public void reset(){
    	t.stop();
    	checkDirection();
    	loadImage();
    }
    
   
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int y = (getHeight()/2) - (image.getHeight()/2);
        if(flag == false)
        	g.drawImage(image, xPos, y, this);
        else 
        	g.drawImage(null, 0, 0, this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        xPos += fast;
        if(direction == 1){
        	 if (!(xPos + image.getWidth() > getWidth())) 
             	repaint();
             else{
            	remove();
     			reset();        			
             }
        }

        if(direction == -1){
        	if(xPos <0) {remove(); reset();}
        	else repaint();
        }
    }
    
    public void display(){
    	int indexFotone = Integer.parseInt(parent.frame.rf.counterLabelSender.getText()) +1;
    	parent.frame.rf.counterLabelSender.setText(""+ indexFotone);
    	Component[] components = parent.panelDisp2.getComponents();
    	JPanel panel = (JPanel)components[1];
    	Component[] components2 = panel.getComponents();
    	colorBefore =components2[indexFotone-1 + parent.frame.Qubits*2].getBackground();
    	components2[indexFotone-1 + parent.frame.Qubits*2].setBackground(Color.yellow);
    	components2[(indexFotone-1)+(parent.frame.Qubits*5)].setBackground(Color.yellow);
    	
    	BufferedImage baseIcon=null;
		try {
			String base = Engine.getItemsBase(arrayBasiOpposite);
			if(base.charAt(indexFotone-1) == 'D'){
				url = getClass().getResource("/images/BaseD.png");
				baseIcon = ImageIO.read(url);
			}else if(base.charAt(indexFotone-1) == 'R'){
				url = getClass().getResource("/images/BaseR.png");
				baseIcon = ImageIO.read(url);
			}
			if(direction == 1)
				parent.frame.rf.base.setIcon(new ImageIcon(baseIcon));
			else parent.frame.sf.base.setIcon(new ImageIcon(baseIcon));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
    }
    
    public void remove(){

    	int indexFotone = Integer.parseInt(parent.frame.rf.counterLabelSender.getText()); 
    	parent.frame.rf.counterLabelReceiver.setText(""+indexFotone); 
    	Component[] components = parent.panelDisp2.getComponents();
    	JPanel panel = (JPanel)components[1];
    	Component[] components2 = panel.getComponents();
    	
    	
    	boolean  flag = arrayCheck.get(indexFotone-1); 
    	
    	if(direction == 1){
    		if(flag == true)
        		components2[indexFotone-1 + parent.frame.Qubits*5].setBackground(Color.green);
        	else components2[indexFotone-1 + parent.frame.Qubits*5].setBackground(Color.red);
    		
    		components2[(indexFotone-1)+(parent.frame.sender.getNQubits()*2)].setBackground(colorBefore);
    	}
    	else{
    		 if(flag == true)
    	    	components2[indexFotone-1 + parent.frame.Qubits*2].setBackground(Color.green);
    	    else components2[indexFotone-1 + parent.frame.Qubits*2].setBackground(Color.red);
    		 components2[(indexFotone-1)+(parent.frame.Qubits*5)].setBackground(Color.white);
    	}
    }
    
    public void changeLower(int i){
      	t.setDelay(i);
      	if(direction == 1) fast = 1;
      	else fast = -1;
    }
    
    public void changeFaseter(int i){
    	if(direction == 1) fast = i;
    	else fast = -i;
      	t.setDelay(1);
    }
    
    private void exit(){
       t.stop(); flag = true; repaint(); 
 	   parent.frame.rf.base.setIcon(null);
 	   parent.frame.sf.base.setIcon(null);  
 	   parent.frame.sf.slider.setValue(10); 
  	   parent.frame.sf.slider.setEnabled(false);
  	   parent.frame.cf.play.setEnabled(true);
   	   if(direction == 1){
   		  parent.frame.cf.labelDisplay1.setText(parent.frame.fase5); 
   		  parent.frame.rf.labelEtSender.setText("Lunghezza Chiave Alice: "); 
   		  parent.frame.rf.labelEtReceiver.setText("Lunghezza Chiave Bob: ");
   		  parent.frame.rf.counterLabelReceiver.setText("0");
     	  parent.frame.rf.counterLabelSender.setText("0");
     	 repaint(); 
   	   }
   	   else {
   		   parent.frame.cf.labelDisplay1.setText(parent.frame.fase4);
   		   parent.frame.rf.counterLabelReceiver.setText("0");
   	  	   parent.frame.rf.counterLabelSender.setText("0");
   	  	repaint(); 
   	   }
      }
}


