package animation;

public enum BaseDefault {
	 DIAGONALE,
	 RETTILINEA,
}
